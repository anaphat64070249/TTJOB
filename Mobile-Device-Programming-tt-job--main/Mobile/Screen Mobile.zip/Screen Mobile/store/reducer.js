import React from "react";

const userObject = {
    status: true,
    user: [],
    test: 'BIg',
    headerShow: true,
    tabBarShow: true,
    filer: ''
}

export default function Reducer(state = userObject, action){
    console.log("Do something Reducer");
    console.log("Action obj: ",action.user);
    switch (action.type){
        case "Login":
            // state.user.push(action.user);
            // console.log("State obj:",state.user[0]);
            console.log(state.test, state.user);
            console.log(state.user.length);
            if (state.user.length >= 1){
                state.user.splice(1, 1);
            }
            return{
                ...state,
                user: state.user.concat(action.user)
            }
        case "header":
            return {
                ...state,
                headerShow: action.bool,
            }
        case "tab":
            return {
                ...state,
                tabBarShow: action.bool,
            }
        case "filter":
            return {
                ...state,
                filter: action.b_type
            }
        default:
            return state
    }
}