import React from "react"

// export const [user, setUser] = React.useState({})
// export var user = ''
export function pushUser(userItem){
    console.log("Do this Store");
    return {type: "Login", user: userItem};
}

export function setHeader(bool){
    return {type: 'header', bool: bool}
}
export function setTabBar(bool){
    return {type: 'tab', bool: bool}
}

export function setFilter(str){
    print("Str:", str)
    return {type: 'filer', b_type: str}
}