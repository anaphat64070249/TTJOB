import React from "react";
import { Dimensions } from 'react-native';
import { View, Text, StyleSheet, FlatList } from "react-native";
import { IconButton } from "react-native-paper";
import { AntDesign } from '@expo/vector-icons';
{/* <AntDesign name="closecircle" size={24} color="black" /> */ }

const { width, height } = Dimensions.get('window');



export default function ListBar(props) {
    const data = props.select;
    const [list, setList] = React.useState(data);
    const removeItem = (del) => {
        let arr = list.filter(function(item) {
          return item !== del;
        })
        setList(arr);
    };

    return (
        <View style={[styles.contianer]}>
            <FlatList data={list} keyExtractor={(item, index) => item + index}
                numColumns={2} renderItem={(data) =>{
                    return (
                        <View data={data} style={[styles.flatListItem]} >
                            <View style={{ flexDirection: 'row',}}>
                                <View style={{padding: width/26}}>
                                    <Text style={{
                                        fontSize: width / 18.19,
                                        textAlign: 'center',
                                    }}>
                                        {data.item}
                                    </Text>
                                </View>
                                <View>
                                    <IconButton
                                        icon={"close-circle-outline"}
                                        iconColor="#FF0108"
                                        size={width / 13.35}
                                        style={{
                                            marginTop: 'auto',
                                            backgroundColor: '#fff',
                                        }}
                                        onPress={() =>{
                                            console.log(data.index, data.item);
                                            removeItem(data.item)
                                        }}
                                    />
                                </View>
                
                            </View>
                        </View>
                    )
                }}
            >
            </FlatList>
        </View>
    )
}

const styles = StyleSheet.create({
    flatListItem: {
        flexDirection: 'row',
        borderColor: '#3A976B',
        borderWidth: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        borderRadius: 7,
        marginHorizontal: 5,
        marginVertical: 5
    }
})
