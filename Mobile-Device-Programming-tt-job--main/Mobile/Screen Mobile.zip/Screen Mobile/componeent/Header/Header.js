import React from "react";
import { View, Text, StyleSheet, } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import Ionicons from '@expo/vector-icons/Ionicons';


export default function CustomHeader(props) {

    if (!props.arrow) {
        props.arrow = true;
    }
    return (
        <View style={styles.header}>
            <View style={styles.item}>
                {props.arrow ? <View>
                    <Ionicons name="arrow-back-sharp"
                        size={width / 10}
                        color={'#fff'}
                        onPress={() => {
                            props.back();
                            props.tabBack()
                            props.navigation.navigate(props.go)
                        }}
                    />
                </View>: <View />}
                <View style={{ marginHorizontal: width / 6.3 }}>
                    <Text
                        style={{
                            fontSize: width / 13, color: '#fff',
                            alignContent: 'center',
                            justifyContent: 'center',
                        }}>
                        {props.title}
                    </Text>
                </View>
            </View>


        </View>
    )
}

const styles = StyleSheet.create({
    header: {
        backgroundColor: '#009F83',
        padding: width / 65,
        flexDirection: 'column',
        height: height / 8.7,
        alignContent: 'center',
        alignItems: 'center'
    },
    item: {
        flexDirection: 'row',
        textAlign: 'center',
        justifyContent: 'center',
        marginVertical: height / 67,
    }
})