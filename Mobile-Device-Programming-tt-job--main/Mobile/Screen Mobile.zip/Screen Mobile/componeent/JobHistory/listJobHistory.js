import React from "react";
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { useSelector } from "react-redux";
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useDispatch } from "react-redux";
import Ionicons from '@expo/vector-icons/Ionicons';
const jobDemo = [
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'พิจารณารายบุคคล',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3
    },
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'พิจารณารายบุคคล',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3
    },

]

export function ListJobHisroty(props) {
    // console.log("../image/" + item.img);
    const dispatch = useDispatch()
    function toggle() {
        dispatch(store.setHeader(false))
    }
    function toggleTab() {
        dispatch(store.setTabBar(false))
    }

    function renderItem(data) {
        const item = data.item;
        return (
            <TouchableOpacity style={[styles.box]}
                onPress={() => {
                    console.log("Select");
                    // toggle();
                    // toggleTab()
                    // props.navigation.navigate("ViewDetail");
                }} >
                <View style={[styles.content]}>
                    <View style={[styles.infoBox]}>
                        <Text style={{ fontSize: width / 14.72, fontWeight: '700' }}>{item.com_name}</Text>
                        <View>
                            <Text>การสมัคร: {item.apply_type}</Text>
                            <Text>ระยะเวลาทำงาน: {item.dayWork}</Text>
                            <Text>เวลาทำงาน: {item.timeStart} - {item.timeEnd}</Text>
                        </View>
                    </View>
                    <View style={{ alignItems: 'flex-end', alignSelf: 'flex-end', alignContent: 'flex-end' }}>
                        <Image source={require('../../image/burgerking.png')} style={[styles.imgStyle]} />
                    </View>
                </View>
                <View style={[styles.tabIcomBar]}>
                    <View style={[styles.hourPay]}>
                        <Text style={{ color: '#fff' }}>{item.pay} บาท/ชั่วโมง</Text>
                    </View>
                    <View style={[styles.position]}>
                        <Text style={{ color: '#fff' }}>{item.position}</Text>
                    </View>
                </View>
                <View style={[styles.score]}>
                    <Ionicons name="star" size={28} color={'#EAC400'} />
                    <View style={{ justifyContent: 'center', padding: 5 }}>
                        <Text>{item.avg_score} คะแนน</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    return (
        <View>
            {/* <View style={[styles.header, styles.col]}>
                <View style={{flexDirection: 'row', marginTop: 10}}>
                    <View>
                        <MaterialCommunityIcons
                            name="arrow-left"
                            size={50}
                            style={{ padding: 5 }}
                            color={"#fff"}
                            onPress={() => {
                                console.log(props);
                                props.setVisible(false)
                            }}
                        />
                    </View>
                    <View style={{
                        alignSelf: 'center',
                        marginHorizontal: width / 8.2
                    }}>
                        <Text style={{
                            fontSize: width / 16.5,
                            fontWeight: '700',
                            color: '#fff',
                            textAlign: 'center'
                        }}>
                            {props.title}
                        </Text>
                    </View>
                </View>
            </View> */}
            <FlatList data={jobDemo} renderItem={renderItem} />
        </View>
    )
}

const styles = StyleSheet.create({
    box: {
        padding: 6,
        backgroundColor: '#E9E9E9',
        flexDirection: 'column',
        marginVertical: 5,
        borderRadius: 5
    },
    content: {
        flexDirection: 'row',
        padding: 5
    },
    infoBox: {
        padding: 3,
        marginVertical: 3,
        width: width / 1.7
    },
    imgStyle: {
        width: width / 3.1,
        height: height / 5.5,
        // marginHorizontal: width / 100.3,
        padding: 1
    },
    tabIcomBar: {
        flexDirection: 'row',
        width: width / 0.3,
        marginHorizontal: 10,
        marginBottom: 5
    },
    hourPay: {
        backgroundColor: '#149D11',
        borderRadius: 20,
        padding: 10,

    },
    position: {
        backgroundColor: '#0066C5',
        borderRadius: 20,
        padding: 10,
        marginHorizontal: 10
    },
    score: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginHorizontal: 10
    },
    com_confirm: {
        backgroundColor: '#1EF1FF',
        padding: 5,
        borderRadius: 5,
    },
    emp_confrim: {
        backgroundColor: '#FFB11B',
        padding: 5,
        borderRadius: 5,
        marginHorizontal: 5
    },
    header: {
        backgroundColor: '#009F83',
        flexDirection: 'row',

    },
})