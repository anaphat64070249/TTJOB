import React from "react";
import { View, Text, Image, ScrollView, StyleSheet } from "react-native";
import { Button } from "react-native-elements";
import { useDispatch, useSelector } from "react-redux";
import SelectDropdown from 'react-native-select-dropdown';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Dimensions } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
const { width, height } = Dimensions.get('window');
import * as globalFunction from '../globalFunction';
import * as personalModel from '../model/personalModel';
import * as address from '../model/address'
import * as store from '../store/store'
import { Dispatch } from "redux";

const userAddress = {
    emp_id: 10000000,
    privince: 'กรุงเทพมหานคร',
}

export default function Filter(props) {
    const [province_id, setPersonal_id] = React.useState(1);
    const [amper_id, setAper_id] = React.useState(0);
    const [tumbon_id, setTumbon_id] = React.useState(0);
    const [type, setType] = React.useState('');
    const dispatch = useDispatch()
    function toglrFilter(str){
        dispatch(store.setFilter(str))
    }
    return (
        <View style={[styles.contianer]}>
            <View style={[styles.content]}>
                <View style={[styles.header, styles.col]}>
                    <View>
                        <MaterialCommunityIcons
                            name="arrow-left"
                            size={50}
                            style={{ padding: 5 }}
                            color={"#fff"}
                            onPress={() => {
                                console.log(props);
                                props.setVisible(false)
                            }}
                        />
                    </View>
                    <View style={{
                        alignSelf: 'center',
                        marginHorizontal: width / 4.2
                    }}>
                        <Text style={{
                            fontSize: width / 16.5,
                            fontWeight: '700',
                            color: '#fff'
                        }}>
                            ตัวกรอง
                        </Text>
                    </View>
                </View>

                <View style={{ marginTop: 5, marginLeft: width / 30 }}>

                    <View style={[styles.setter]}>
                        <Text style={{
                            fontSize: width / 14.3
                        }}>
                            เลือกประเภทงาน
                        </Text>
                        <View style={[styles.buttonSelect]}>
                            <SelectDropdown
                                data={globalFunction.getTypeJob()}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    console.log(selectedItem);
                                    setType(selectedItem)
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    
                                    return item;
                                }}
                                defaultButtonText="เลือกประเภทงาน"
                                buttonStyle={styles.setlect}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                            />
                        </View>
                    </View>

                    {/* <View style={[styles.setter, { marginTop: -10 }]}>
                        <Text style={{
                            fontSize: width / 14.3
                        }}>
                            เลือกตำแหน่งงาน
                        </Text>
                        <View style={[styles.buttonSelect]}>
                            <SelectDropdown
                                data={globalFunction.getTypeJob()}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    return item;
                                }}
                                defaultButtonText="เลือกตำแหน่งงาน"
                                buttonStyle={styles.setlect}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                            />
                        </View>
                    </View> */}
{/* 
                    <View style={[styles.setter, { marginTop: -10 }]}>
                        <Text style={{
                            fontSize: width / 14.3
                        }}>
                            เลือกพิกัด อำเภอ/เขต
                        </Text>
                        <View style={[styles.buttonSelect]}>
                            <SelectDropdown
                                data={address.GetAmper(1)}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    return item.name_th;
                                }}
                                defaultButtonText="เลือกประเภทงาน"
                                buttonStyle={styles.setlect}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                                onSelect={() =>{
                                    
                                }}
                            />
                        </View>
                    </View> */}

                    {/* <View style={[styles.setter, { marginTop: -10 }]}>
                        <Text style={{
                            fontSize: width / 14.3
                        }}>
                            เลือกพิกัด ตำบล/แขวง
                        </Text>
                        <View style={[styles.buttonSelect]}>
                            <SelectDropdown
                                data={globalFunction.getTypeJob()}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    return item;
                                }}
                                defaultButtonText="เลือกประเภทงาน"
                                buttonStyle={styles.setlect}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                            />
                        </View>
                    </View> */}

                    <View style={{
                        flexDirection: 'row', marginHorizontal: width / 25
                    }}>
                        {/* <Button title={"ล้างทั้งหมด"}
                            buttonStyle={{
                                padding: 10,
                                width: width / 2.45,
                                borderRadius: 5,
                                backgroundColor: '#DEA126'
                            }}
                        /> */}
                        <Button title={"ค้นหา"}
                            buttonStyle={{
                                padding: 10,
                                // marginHorizontal: width / 5,
                                width: width / 2.45,
                                borderRadius: 5,
                                backgroundColor: '#0B33C1'
                            }}
                            onPress={() =>{
                                console.log("AAAA");
                                console.log(type);
                                // toglrFilter(type)
                            }}
                        />
                    </View>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1,
        backgroundColor: '#EFEEEA',
    },
    col: {
        flexDirection: 'row',
    },
    content: {
        marginTop: height / 25
    },
    header: {
        backgroundColor: '#009F83',
    },
    setter: {
        marginTop: height / 79,
        padding: width / 25,
    },
    setlect: {
        width: width / 1.17,
        padding: 1,
        marginTop: 5,
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 5
    },
    buttonSelect: {

    },
    styleButton: {
        width: width / 2.8,
        marginTop: 3
    }
});
