import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, Platform } from "react-native";
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Dimensions } from "react-native";
var { width, height } = Dimensions.get('window');
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import * as store from '../../store/store';
// console.log(Platform);




export default function TabBarButtonCost(props) {
    const dispatch = useDispatch();
    const tab = useSelector(state => state.tabBarShow);
    console.log("on Tab:", tab);

    function toggleHeader(bool) {
        dispatch(store.setHeader(bool));
    }
    function toggleTabBarShown(bool) {
        dispatch(store.setTabBar(bool))
    }

    return (
        <View>
            <TouchableOpacity style={[styles.button, ]}
                onPress={() => {
                    toggleHeader(props.header);
                    toggleTabBarShown(props.tabBar)
                    props.navigation.navigate(props.navigate)
                }}
            >
                <MaterialCommunityIcons
                    style={{
                        alignSelf: 'center'
                    }}
                    name={props.name}
                    size={width /10.5} color="#fff"
                />
                <Text style={{ color: '#fff', fontSize: width / 25 }}>
                    {props.title}
                </Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    button: {
        padding: width / 90.2,
        marginLeft: width / 27,
        justifyContent: 'center',
        alignSelf: 'center'
    }
})