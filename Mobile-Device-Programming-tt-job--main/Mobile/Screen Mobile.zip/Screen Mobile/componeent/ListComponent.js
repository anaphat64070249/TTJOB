import React from "react";
import { View, FlatList, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import Ionicons from '@expo/vector-icons/Ionicons';
import { AntDesign } from '@expo/vector-icons';
import { useDispatch } from "react-redux";
import * as store from '../store/store'
import * as globalFunction from '../globalFunction';
import { Button } from "react-native-elements";
import axios from "axios";

export function ListJob(props) {
    const item = props.data.item;
    // console.log("props ",props.data.item);
    const dispatch = useDispatch()
    function toggle() {
        dispatch(store.setHeader(false))
    }
    function toggleTab() {
        dispatch(store.setTabBar(false))
    }
    return (
        <TouchableOpacity style={[styles.box]}
            onPress={() => {
                toggle();
                toggleTab()
                props.navigation.navigate("ViewDetail", {view: props.data.item});
            }} >
            <View style={[styles.content]}>
                <View style={[styles.infoBox]}>
                    <Text style={{ fontSize: width / 14.72, fontWeight: '700' }}>{item.companyName}</Text>
                    <View>
                        <Text style={{fontSize: width /26.2}}>
                            การสมัคร: {item.apply_type == 1 ? 'สมัครแล้วรับทันที': 'พิจณารายบุคคล'}
                        </Text>
                        <Text style={{fontSize: width /26.2}}>เวลาทำงาน: {item.time_start} - {item.time_end}</Text>
                        <Text style={{fontSize: width /26.2}}>ระยะเวลาทำงาน: {item.day_work} วัน</Text>
                    </View>
                </View>
                <View style={{ alignItems: 'flex-end', alignSelf: 'flex-end', alignContent: 'flex-end' }}>
                    <Image source={{uri: item.image_company}} style={[styles.imgStyle]} />
                </View>
            </View>
            <View style={[styles.tabIcomBar]}>
                <View style={[styles.hourPay]}>
                    <Text style={{ color: '#fff' }}>{item.pay} บาท/ชั่วโมง</Text>
                </View>
                <View style={[styles.position]}>
                    <Text style={{ color: '#fff' }}>{item.position}</Text>
                </View>
            </View>
            <View style={[styles.score]}>
                <Ionicons name="star" size={28} color={'#EAC400'} />
                <View style={{ justifyContent: 'center', padding: 5 }}>
                    <Text>{item.avg_score.toFixed(1)} คะแนน</Text>
                </View>
            </View>
        </TouchableOpacity>
    )
}


export function WorkingJob(props) {
    const item = props.data;
    console.log("1ITEM",props.data);
    const dayStart = new Date(item.day_start);
    const dayEnd = new Date(item.day_end);
    const dispatch = useDispatch()
    function toggle() {
        dispatch(store.setHeader(false))
    }
    function toggleTab() {
        dispatch(store.setTabBar(false))
    }
    return (
        <View style={[styles.box, { backgroundColor: '#ECF9F5' }]} >
            <View style={[styles.content]}>
                <View style={[styles.infoBox, { width: width / 1.53 }]}>
                    <Text style={{ fontSize: width / 14.72, fontWeight: '700' }}>{item.companyName}</Text>
                    <View>
                        <Text>การสมัคร: {item.apply_type == 1? "สมัครแล้วรับเลย": "พิจารณารายบุคคล"}</Text>
                        <Text>
                            วันที่เริ่มงาน: {globalFunction.getDay(dayStart.getDay())} {dayStart.getDate()}
                            {' ' + globalFunction.getMonth(dayStart.getMonth())} {dayStart.getFullYear()}
                        </Text>
                        <Text>
                            ถึง: {globalFunction.getDay(dayEnd.getDay())} {dayEnd.getDate()}
                            {' ' + globalFunction.getMonth(dayEnd.getMonth())} {dayEnd.getFullYear()}
                        </Text>
                        <Text>ระยะเวลาทำงาน: {item.day_work}</Text>
                        <Text>เวลาทำงาน: {item.time_start} - {item.time_end}</Text>
                    </View>
                </View>
                <View style={{ alignItems: 'flex-end', alignSelf: 'flex-end', alignContent: 'flex-end', }}>
                    <Image source={{uri: item.image_company}} style={{
                        width: width > 600 ? 200:width / 3.6,
                        height: height > 800 ? 200: height / 6.1,
                    }} />
                </View>
            </View>
            <View style={[styles.tabIcomBar]}>
                <View style={[styles.com_confirm]}>
                    <Text>{item.com_confirm ? "นายจ้างรับคุณเข้าทำงานแล้ว" : 'รอผู้จ้างยืนยัน'}</Text>
                </View>
                <View style={[styles.emp_confrim]}>
                    <Text>{item.com_confirm ? "ผู้สมัครยืนยันรับงานแล้ว" : 'รอคุณยืนยัน'}</Text>
                </View>
            </View>
            <View style={[styles.tabIcomBar]}>
                <View style={[styles.hourPay]}>
                    <Text style={{ color: '#fff' }}>{item.pay} บาท/ชั่วโมง</Text>
                </View>
                <View style={[styles.position]}>
                    <Text style={{ color: '#fff' }}>{item.position}</Text>
                </View>

            </View>
            <View style={{ padding: 5 }}>
                <Button title={"จบงานและประเมินผู้จ้าง"}
                    style={{
                        width: width / 1.72
                    }}
                    buttonStyle={{
                        backgroundColor: '#B20783'
                    }}
                    onPress={()=>{
                        props.navigation.navigate("Review", 
                        {
                            item: item
                        }
                        );
                    }}
                />
            </View>
        </View>
    )
}

export function ApplyJob(props) {
    // console.log("Prop: ", props.data);
    const item = props.data.item;
    console.log(item);
    const dayStart = new Date(item.day_start);
    const dayEnd = new Date(item.day_end);
    // console.log("../image/" + item.img);
    const dispatch = useDispatch();
    function toggle() {
        dispatch(store.setHeader(false))
    }
    function toggleTab() {
        dispatch(store.setTabBar(false))
    }
    return (
        <View style={[styles.box, { backgroundColor: '#ECF9F5' }]} >
            <View style={[styles.content]}>
                <View style={[styles.infoBox, { width: width / 1.53 }]}>
                    <Text style={{ fontSize: width / 14.72, fontWeight: '700' }}>{item.companyName}</Text>
                    <View>
                        <Text>การสมัคร: {item.apply_type == 1? "สมัครแล้วรับเลย": "พิจารณารายบุคคล"}</Text>
                        <Text>
                            วันที่เริ่มงาน: {globalFunction.getDay(dayStart.getDay())} {dayStart.getDate()}
                            {' ' + globalFunction.getMonth(dayStart.getMonth())} {dayStart.getFullYear()}
                        </Text>
                        <Text>
                            ถึง: {globalFunction.getDay(dayEnd.getDay())} {dayEnd.getDate()}
                            {' ' + globalFunction.getMonth(dayEnd.getMonth())} {dayEnd.getFullYear()}
                        </Text>
                        <Text>ระยะเวลาทำงาน: {item.day_work}</Text>
                        <Text>เวลาทำงาน: {item.time_start} - {item.time_end}</Text>
                    </View>
                </View>
                <View style={{ alignItems: 'flex-end', alignSelf: 'flex-end', alignContent: 'flex-end', }}>
                    <Image source={require('../image/burgerking.png')} style={{
                        width: width > 600 ? 200:width / 3.6,
                        height: height > 800 ? 200: height / 6.1,
                    }} />
                </View>
            </View>
            <View style={[styles.tabIcomBar]}>
                <View style={[styles.com_confirm]}>
                    <Text>{item.com_confirm ? "นายจ้างรับคุณเข้าทำงานแล้ว" : 'รอผู้จ้างยืนยัน'}</Text>
                </View>
                <View style={[styles.emp_confrim]}>
                    <Text>{item.emp_confirm ? "ผู้สมัครยืนยันรับงานแล้ว" : 'รอคุณยืนยัน'}</Text>
                </View>
            </View>
            <View style={[styles.tabIcomBar]}>
                <View style={[styles.hourPay]}>
                    <Text style={{ color: '#fff' }}>{item.pay} บาท/ชั่วโมง</Text>
                </View>
                <View style={[styles.position]}>
                    <Text style={{ color: '#fff' }}>{item.position}</Text>
                </View>
            </View>
            <View style={{ padding: 5, flexDirection: 'row' }}>
                <Button title={"ยืนยัน"} disabled={item.emp_confirm}
                    style={{
                        width: width / 3.72
                    }}
                    buttonStyle={{
                        backgroundColor: '#0066C5'
                    }}

                    onPress={ async () =>{
                        // /update/confirm
                        const st = await axios.put('http://127.0.0.1:5000/apply/update',{
                            emp_id: props.user.emp_id,
                            job_id: item.job_id,
                            emp_confirm: true
                        });
                        item.emp_confirm = true;
                        Alert.alert("ยืนยันแล้ว")
                    }}

                />
                <Button title={"ยกเลิกใบสมัคร"}
                    style={{
                        width: width / 2.72,
                        marginHorizontal: 5
                    }}
                    buttonStyle={{
                        backgroundColor: '#9D114C'
                    }}
                    onPress={() =>{
                        console.log('http://127.0.0.1:5000/apply/cancle?userID='+props.user.emp_id+"&jobID="+item.job_id);
                        axios.delete('http://127.0.0.1:5000/apply/cancel/'+props.user.emp_id+'/'+item.job_id);
                        Alert.alert("ลบแล้ว");
                    }}
                />
            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    box: {
        padding: 6,
        backgroundColor: '#E9E9E9',
        flexDirection: 'column',
        marginVertical: 5,
        borderRadius: 5
    },
    content: {
        flexDirection: 'row',
        padding: 5
    },
    infoBox: {
        padding: 3,
        marginVertical: 3,
        width: width / 1.7
    },
    imgStyle: {
        width: width > 600? 250 :width / 3.1,
        height: height > 700? 250: height / 5.5,
        // marginHorizontal: width / 100.3,
        padding: 1
    },
    tabIcomBar: {
        flexDirection: 'row',
        width: width / 0.3,
        marginHorizontal: 10,
        marginBottom: 5
    },
    hourPay: {
        backgroundColor: '#149D11',
        borderRadius: 20,
        padding: 10,
        
    },
    position: {
        backgroundColor: '#0066C5',
        borderRadius: 20,
        padding: 10,
        marginHorizontal: 10
    },
    score: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginHorizontal: 10
    },
    com_confirm: {
        backgroundColor: '#1EF1FF',
        padding: 5,
        borderRadius: 5,
    },
    emp_confrim: {
        backgroundColor: '#FFB11B',
        padding: 5,
        borderRadius: 5,
        marginHorizontal: 5
    }
})