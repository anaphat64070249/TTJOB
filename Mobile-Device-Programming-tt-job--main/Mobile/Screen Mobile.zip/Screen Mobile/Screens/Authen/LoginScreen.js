import React from "react";
import { View, Text, StyleSheet, Image, TextInput, Alert } from "react-native";
import { Button } from 'react-native-elements';
import { Dimensions } from 'react-native';
const { width, height } = Dimensions.get('window');
import axios from "axios";

import { useDispatch } from "react-redux";
import * as store from '../../store/store'


async function login(username, password) {
    // let user = "User123";
    // let pass = "Admin1234"
    // if (user === username && pass === password) {
    //     return true;
    // } else {
    //     Alert.alert("รหัสผ่านหรือชื่อผู้ใช้ไม่ถูกต้อง!");
    //     return false;
    // }
    const login = {
        username: username,
        password: password
    }
    const athen = await axios.post("http://127.0.0.1:5000/auth/login", login);
    console.log(athen.data);
    if (athen.data.authStatus == false){
        return athen.data;
    }
    return (athen.data);
}

export default function LoginScreen({ navigation }) {
    const [username, setUserName] = React.useState('');
    const [password, setPassword] = React.useState('');

    const dispatch = useDispatch();
   async function toggleLogin(user) {
        console.log("Do Dispatch");
        dispatch(store.pushUser(user))
    }
    return (
        <View style={[styles.container]}>
            <View style={[styles.content]}>
                <Image source={require('../../image/Logo_ttjob.png')} style={{
                    width: width / 2.58, height: height / 3.731
                }} />
            </View>
            <View style={{ alignItems: 'center' }}>
                <Text style={{ color: "#FDFFFF", fontSize: width / 13.412, }}>เข้าสู่ระบบ</Text>
            </View>
            <View style={[styles.formLogin]}>
                <View>
                    <Text style={styles.textLabel}>เบอร์มือถือ หรือ อีเมล</Text>
                    <TextInput placeholder="08xxxxxxxx / example@mail.com" value={username}
                        style={[styles.input]} onChangeText={setUserName}
                    />
                </View>
                <View style={{ marginTop: height / 104.2 }}>
                    <Text style={styles.textLabel}>รหัสผ่าน</Text>
                    <TextInput placeholder="password" value={password}
                        style={[styles.input]} onChangeText={setPassword}
                    />
                </View>
                <View>
                    <Button title={"เข้าสู่ระบบ"}
                        containerStyle={{
                            width: width / 2.42,
                            marginTop: height / 53,
                            borderRadius: width / 77.42,
                        }}
                        titleStyle={{
                            fontSize: width / 18.88,
                            padding: 5,
                        }}
                        buttonStyle={{
                            backgroundColor: '#1405C3'
                        }}
                        onPress={async () => {
                            console.log("Test");
                            // const status = await login("User123", "Admin1234");
                            const res = await login(username, password);
                            if (res.authStatus == true) {
                                toggleLogin(res.user);
                                navigation.navigate("App")
                            }else{
                                if (res.errorType === "Incorrect password"){
                                    Alert.alert(
                                        "อีเมล/เบอร์มือถือ หรือ รหัสผ่าน ไม่ถูกต้องลองใหม่อีกครั้ง"
                                    )
                                    setUserName('')
                                    setPassword('')
                                }
                                if (res.errorType === "Account does not exist."){
                                    Alert.alert(
                                        "บัญชีของคุณยังไม่ถูกยืนยันตัวตนจากผู้ดูแลระบบ โปรดติดต่อเจ้าหน้าที่ email: admin@ttjob.com"
                                    )
                                    setUserName('')
                                    setPassword('')
                                }

                            }
                        }}
                    />
                </View>
                <View>
                    <Text style={[styles.text_footer, { marginTop: height / 82.51, textDecorationLine: 'underline' }]}>ลืมรหัสผ่าน</Text>
                    <Text style={[styles.text_footer, { marginTop: height / 82.51, textDecorationLine: 'underline' }]} onPress={() => { navigation.navigate("Welcome") }} >ยังไม่ได้สมัครสมาชิกกลับสู่หน้าหลัก</Text>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 20,
        backgroundColor: "#009F83",
        flexDirection: 'column'
    },
    content: {
        marginTop: height / 42.1134,
        padding: 15,
        alignItems: 'center'
    },
    btn: {
        padding: 5,
        textAlign: 'center',
        alignItems: 'center'
    },
    text_footer: {
        fontSize: width / 25.4, color: '#fff'
    },
    formLogin: {
        width: width / 1.2,
        padding: 10,
        // backgroundColor: '#330066',
        alignSelf: 'center'
    },
    textLabel: {
        fontSize: width / 22.2,
        color: '#feffff'
    },
    input: {
        backgroundColor: '#fff',
        borderRadius: 5,
        padding: 12,
        fontSize: width / 21.621
    },

})