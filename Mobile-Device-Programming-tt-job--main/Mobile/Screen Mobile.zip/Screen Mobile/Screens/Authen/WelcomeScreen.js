import React from "react";
import { View, Text, StyleSheet, Image, ImageBackground, Platform, } from "react-native";
import { Button } from 'react-native-elements';
import { Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');
// console.log(Platform.constants.interfaceIdiom, width, height);

export default function WelcomeScreen({navigation}) {
    return (
        <View style={[styles.container]}>
            <View style={[styles.content]}>
                <Image source={require('../../image/Logo_ttjob.png')} style={{
                    //width: width / 2.02, height: height / 2.681
                    width: width / 2.58, height: height / 3.731
                }} />
            </View>
            <View style={{ alignItems: 'center' }}>
                <Text style={{ color: "#FDFFFF", fontSize: width / 13.412, }}>Welcome to TT-Job</Text>
            </View>
            <View style={styles.btn}>
                <Button title="เข้าสู่ระบบ"
                    titleStyle={{
                        fontSize: width / 18.59, fontWeight: '700',
                        padding: 5,
                        color: '#000000'
                    }}
                    containerStyle={{
                        padding: 5,
                        width: width / 1.43,
                        marginTop: 4,
                    }}
                    buttonStyle={{
                        backgroundColor: '#ffffff',
                        borderRadius: 10
                    }}
                    onPress={() => {navigation.navigate("Login")}}
                />
            </View>
            <View style={styles.btn}>
                <Button title="สมัครสมาชิก"
                    titleStyle={{
                        fontSize: width / 18.59, padding: 5, fontWeight: '700',
                        color: '#000000'
                    }}
                    containerStyle={{
                        padding: 5,
                        width: width / 1.43,
                        marginTop: 0,
                    }}
                    buttonStyle={{
                        backgroundColor: '#ffffff',
                        borderRadius: 10
                    }}
                    onPress={() => {navigation.navigate("Register")}}
                />
            </View>
            <View style={{ flexDirection: 'row', marginTop: height / 70.33, justifyContent: 'center' }}>
                <Text style={styles.text_footer}>ไปยังเว็บไซต์ของเรา</Text>
                <Text style={[{
                    marginTop: 0, marginLeft: width / 59,
                    fontSize: height / 35, color: '#0035FF', textDecorationLine: 'underline'
                }]}>
                    tt-jobs
                </Text>
            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 20,
        backgroundColor: "#009F83",
        flexDirection: 'column'
    },
    content: {
        marginTop: height / 42.1134,
        padding: 15,
        alignItems: 'center'
    },
    btn: {
        padding: 5,
        textAlign: 'center',
        alignItems: 'center'
    },
    text_footer: {
        fontSize: width / 25.4,color: '#fff'
    }
})