import React from "react";
import { View, StyleSheet, Text, Image, SafeAreaView, ScrollView, Alert } from "react-native";
import { Button } from "react-native-elements";
import SelectDropdown from 'react-native-select-dropdown';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Dimensions } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
const { width, height } = Dimensions.get('window');
import * as globalFunction from '../../globalFunction'
import { TextInput } from "react-native-gesture-handler";
import axios from "axios";
import { useSelector } from "react-redux";


// const item = {
//     com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
//     com_id: 10000000,
//     apply_type: 'พิจารณารายบุคคล',
//     timeStart: '13.30',
//     timeEnd: '20:00',
//     dayWork: 1,
//     pay: 48,
//     position: 'พนักงานซักผ้า',
//     img: 'burgerking.png',
//     avg_score: 7.3,
//     dayStart: "2023-10-12",
//     dayEnd: "2023-10-12",
//     com_confirm: true,
//     emp_confirm: true,
//     manager_name: 'Jack Drunker'
// }

export default function ReviewScreen({ navigation, route }) {
    const [item, setItem] = React.useState([]);
    const [comInfo, setComInfo] = React.useState([]);
    const dayStart = new Date(item.day_start);
    const dayEnd = new Date(item.day_end);
    const [score, setScore] = React.useState(0);
    const [comment, writeComment] = React.useState('');
    const [report, setReport] = React.useState('');
    const user = useSelector(state => state.user[0]);
    const [fullName, setFullName] = React.useState("");
    React.useEffect(() =>{
        console.log("LOG PARAMS :",route.params.item);
        setItem(route.params.item);
        axios.get("http://127.0.0.1:5000/evaluate/info/"+route.params.item.job_id)
        .then((res) =>{
            setComInfo(res.data);
            console.log("ReviewInfo: ",res.data);
        }).finally(() =>{
            console.log('http://127.0.0.1:5000/emp/fullName/'+user.emp_id);
            axios.get('http://127.0.0.1:5000/emp/fullName/'+user.emp_id).then((res)=>{
                let name = res.data.firstName + " "+res.data.lastName;
                setFullName(name);
            }).finally(() =>{
                console.log(fullName);
            });
        })
    }, []);

    return (
        <View style={styles.contianer}>
            <ScrollView>
                <View>
                    <View style={{ alignItems: 'center', marginVertical: 15 }}>
                        <Image source={require('../../image/burgerking.png')} style={[styles.logo]} />
                    </View>
                    <View style={styles.headerInfo}>
                        <Text style={{ fontSize: width / 18.3, fontWeight: '700' }}>{item.com_name}</Text>
                        <Text style={{ fontSize: width / 24.3 }}>การสมัคร: {item.apply_type}</Text>
                        <Text style={{ fontSize: width / 24.3 }}>
                            วันที่เริ่มงาน: {globalFunction.getDay(dayStart.getDay())} {dayStart.getDate()}
                            {' ' + globalFunction.getMonth(dayStart.getMonth())} {dayStart.getFullYear()}
                        </Text>
                        <Text style={{ fontSize: width / 24.3 }}>
                            ถึง: {globalFunction.getDay(dayEnd.getDay())} {dayEnd.getDate()}
                            {' ' + globalFunction.getMonth(dayEnd.getMonth())} {dayEnd.getFullYear()}
                        </Text>
                        <Text style={{ fontSize: width / 24.3 }}>ระยะเวลาทำงาน: {item.day_work}</Text>
                        <Text style={{ fontSize: width / 24.3 }}>เวลาทำงาน: {item.time_start} - {item.time_end}</Text>
                    </View>

                    <View style={[styles.tabIcomBar]}>
                        <View style={[styles.hourPay]}>
                            <Text style={{ color: '#fff', fontSize: width / 27.2 }}>{item.pay} บาท/ชั่วโมง</Text>
                        </View>
                        <View style={[styles.position]}>
                            <Text style={{ color: '#fff', fontSize: width / 27.2 }}>{item.position}</Text>
                        </View>

                    </View>
                </View>
                <View style={styles.form}>
                    <View >
                        <Text style={{ fontSize: width / 22.3, }} >
                            ชื่อผู้จัดการ/หัวหน้างาน: {item.manager_name}
                        </Text>
                    </View>
                    <View style={styles.form_write}>
                        <View>
                            <Text style={{ fontSize: width / 20.3, fontWeight: '700' }}>
                                ให้คะแนนผู้จ้างงาน
                            </Text>
                            <SelectDropdown
                                data={[0, 0.5, 1.5, 2, 2.5, 3, 3.5, 4, 4.5,
                                    5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10
                                ]}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    return item;
                                }}
                                onSelect={(selectedItem, index) => {
                                    console.log(selectedItem);
                                    setScore(selectedItem);
                                }}
                                defaultButtonText="เลือกคะแนน"
                                buttonStyle={styles.selectionScore}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                            />
                        </View>
                        <View style={{ marginTop: height / 53 }}>
                            <Text style={{ fontSize: width / 24.3, fontWeight: '700' }}>
                                ความคิดเห็น (ไม่บังคับ)
                            </Text>
                            <TextInput
                                style={{
                                    borderWidth: 1,
                                    backgroundColor: '#fff',
                                    height: height / 6,
                                    marginTop: 5,
                                    padding: 10
                                }}
                                numberOfLines={5}
                                multiline
                                editable
                            />
                        </View>
                        <View style={{ marginTop: height / 53 }}>
                            <Text style={{ fontSize: width / 24.3, fontWeight: '700' }}>
                                รายงานปัญหา หรือ ความผิดปกติ (ไม่บังคับ)
                            </Text>
                            <SelectDropdown
                                data={[
                                    "ผู้จ้างใช้คำพูดไม่สุภาพ หรือ พูดจาคุกคามทางเพศ", 
                                    "ใช้ความรุนแรงหรือการแก้ไขสถานการณ์ด้วยวิธีที่ไม่เหมาะสม",
                                    "ไม่ให้ความสำคัญหรือการละเมิดสิทธิของลูกจ้างตามกฎหมายหรือนโยบายการทำงาน",
                                    "ผู้จ้างไม่ชำระเงินค่าจ้างตามที่ตกลงไว้"
                                ]}
                                buttonTextAfterSelection={(selectedItem, index) => {
                                    return selectedItem;
                                }}
                                rowTextForSelection={(item, index) => {
                                    return item;
                                }}
                                onSelect={(selectedItem, index) => {
                                    console.log(selectedItem);
                                    setReport(selectedItem)
                                }}
                                defaultButtonText=""
                                buttonStyle={styles.selectionReport}
                                buttonTextStyle={{
                                    fontSize: width / 27.6
                                }}
                                renderDropdownIcon={isOpne => {
                                    return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                                }}
                            />
                        </View>
                        <View style={{marginTop: height / 70}}>
                            <Button title={'ส่งแบบประเมิน'}
                                buttonStyle={{
                                    width: width / 2.4,
                                    padding: 5,
                                    borderRadius: 5,
                                    backgroundColor: '#009F83'
                                }}
                                titleStyle={{
                                    fontSize: width / 18
                                }}
                                onPress={ async () =>{
                                    let sttus = false;
                                    await axios.post("http://127.0.0.1:5000/evaluate/", {
                                        emp_id: user.emp_id,
                                        job_id: item.job_id,
                                        manager_name: comInfo.manager_name,
                                        reviewer_name: fullName,
                                        reviewer: "emp",
                                        report: report,
                                        comments: comment,
                                        score: score
                                    }).then(async (res) =>{
                                        if (res.data.status == true){
                                            Alert.alert("ประเมินเสร็จสิน");
                                            
                                        }else{
                                            Alert.alert("เกิดข้อผิดพลาด");
                                        }
                                        
                                    }).catch(error =>{
                                        console.log(error);
                                        Alert.alert("เกิดข้อมผิดพลาด");
                                    });

                                    navigation.navigate("ViewMyjob");

                                }}
                            />
                        </View>

                    </View>
                </View>
            </ScrollView>
        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1,
    },
    logo: {
        width: 190,
        height: 190,
    },
    headerInfo: {
        alignSelf: 'center'

        // marginHorizontal: width / 23
    },
    tabIcomBar: {
        flexDirection: 'row',
        width: width / 0.3,
        marginHorizontal: width / 6,
        marginBottom: 5,
        marginVertical: height / 80,

    },
    hourPay: {
        backgroundColor: '#149D11',
        borderRadius: 20,
        padding: width / 26.4,

    },
    position: {
        backgroundColor: '#0066C5',
        borderRadius: 20,
        padding: width / 26.4,
        marginHorizontal: width / 16.8
    },
    form: {
        marginVertical: height / 48,
        padding: 10,
        marginHorizontal: width / 18
    },
    form_write: {
        marginVertical: 15
    },
    selectionScore: {
        width: width / 1.77,
        padding: 5,
        marginTop: 5,
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 5
    },
    selectionReport: {
        width: width / 1.18,
        padding: 5,
        marginTop: 5,
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 5
    },
});