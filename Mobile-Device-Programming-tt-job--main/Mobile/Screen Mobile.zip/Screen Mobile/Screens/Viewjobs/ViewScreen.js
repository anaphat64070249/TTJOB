import React from "react";
import { View, Text, Image, FlatList, StyleSheet, Modal, Alert } from "react-native";
import { useSelector } from "react-redux";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Button } from "react-native-elements";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import * as listComponent from '../../componeent/ListComponent';
import * as globalFunction from '../../globalFunction';
import * as ListJob from "../../componeent/ListComponent";
import * as store from '../../store/store';
import { useDispatch } from "react-redux";
import Filter from "../../componeent/Fillter";
import { StatusBar } from "expo-status-bar";
import axios from "axios";
import { ScrollView } from "react-native-gesture-handler";


const jobDemo = [
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'พิจารณารายบุคคล',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3
    },
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'พิจารณารายบุคคล',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3
    },

]

export default function ViewJob({ route, navigation }) {
    const [jobItem, setJobItem] = React.useState([]);
    const listDayIndex = ["จ", 'อ', 'พ', 'พฤ', 'ศ', 'ส', 'อา']
    const today = new Date();
    const [dateFilter, setDateFilter] = React.useState(today);
    const b_type = useSelector(state => state.filer);
    const [filterList, setfilterList] = React.useState([])
    React.useEffect(() => {
        let myday = dateFilter.getFullYear() + "-"+(dateFilter.getMonth()+1)+"-"+dateFilter.getDate();
        console.log(myday);
        console.log('http://127.0.0.1:5000/job/job_on_date/'+myday);
        axios.get('http://127.0.0.1:5000/job/job_on_date/'+myday)
            .then((res) => { setJobItem(res.data); console.log(res.data); })
            .catch((err) => console.log(err));
    }, [dateFilter]);

    // function togleFilter(){
    //     let myday = dateFilter.getFullYear() + "-"+(dateFilter.getMonth()+1)+"-"+dateFilter.getDate();
    //     axios.get('http://127.0.0.1:5000/job/filterByposition?position='+position_type+"?day"+ myday)
    //     .then(() =>{
    //     });

    // }

    // React.useState(() =>{
    //     console.log("DO USERSTATE");
    //     let myday = dateFilter.getFullYear() + "-"+(dateFilter.getMonth()+1)+"-"+dateFilter.getDate();
    //     console.log('http://127.0.0.1:5000/job/filterByposition?position='+b_type+"?day="+ myday);
        
    //     axios.get('http://127.0.0.1:5000/job/filterByposition?position='+b_type+"?day="+ myday)
    //     .then((res) =>{
    //         jobItem(res.data)
    //     });

    // }, b_type)

    const user = useSelector(state => state.user[0])
    console.log("Use Store", user);

    const [openDate, setOpenDate] = React.useState(false);
    const [modal, setModals] = React.useState(false);
    const dispatch = useDispatch();

    function setHeader(bool) {
        dispatch(store.setHeader(bool));
    }
    function setTabBar(bool) {
        dispatch(store.setTabBar(bool))
    }
    function getVistbleModal() {
        const mymodal = modal;
        return mymodal;
    }

    function renderJob(item) {
        return (
            <ListJob.ListJob data={item} navigation={navigation} ></ListJob.ListJob>
        );
    }

    if (jobItem === undefined) {
        return (
            <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 42, textAlign: 'center', alignSelf: 'center', marginTop: 30 }}>
                    Loading...
                </Text>
            </View>
        )
    }

    return (
        <View style={{ flex: 1 }}>
            
            <View style={[styles.filterBar]}>
                <View style={{ flexDirection: 'row', marginVertical: 10 }}>
                
                    <Button title={listDayIndex[dateFilter.getDay() - 1] +
                        ' ' + dateFilter.getDate() + ' / ' + (dateFilter.getMonth()+1) + ' / ' + (dateFilter.getFullYear() + 543)}
                        style={[]}
                        containerStyle={[styles.filterButtonContianer]}
                        titleStyle={{ color: '#000' }}
                        buttonStyle={[styles.filterButton]}
                        onPress={() =>
                            setOpenDate(true)
                        }
                    />
                    <DateTimePickerModal
                        mode="date"
                        isVisible={openDate}
                        onConfirm={(date) => {
                            setDateFilter(date);
                            setOpenDate(false)
                        }}
                        onCancel={() => {
                            setOpenDate(false)
                            setDateFilter(today)
                        }}
                    />
                    <Button title={"ตัวกรอง"} style={[]}
                        containerStyle={[styles.filterButtonContianer]}
                        titleStyle={{ color: '#000' }}
                        buttonStyle={[styles.filterButton]}
                        onPress={() => {
                            setModals(!modal)
                        }}
                    />
                </View>
            </View>

            {!jobItem ?
                <View>
                    <Text style={{ fontSize: 42, textAlign: 'center', alignSelf: 'center', marginTop: 30 }}>
                    Loading...
                </Text>
                </View> :
                <View style={[styles.contianer]}>
                    <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modal}
                    >
                        <Filter setVisible={setModals} />
                    </Modal>
                    <FlatList data={jobItem} renderItem={renderJob} />
                </View>}
        </View>
    )
}


const styles = StyleSheet.create({
    contianer: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
    },
    filterBar: {
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '#DCDCDC'
    },
    filterButtonContianer: {
        padding: 5,
        width: width / 2.2
    },
    filterButton: {
        backgroundColor: '#F0F0F0',
        borderWidth: 1,
        borderColor: '#000',
        borderRadius: 5,
    },

});


