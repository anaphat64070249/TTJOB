import React, { useEffect } from "react";
import { View, Text, Image, ScrollView, StyleSheet, Alert } from "react-native";
import { Button } from "react-native-elements";
import { Dimensions } from "react-native";
import * as globalFunction from '../../globalFunction'
const { width, height } = Dimensions.get('window');
import { useSelector } from "react-redux";
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import * as Location from 'expo-location';
import Checkbox from 'expo-checkbox';
import axios from "axios";

const detail = {
    com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
    com_id: 10000000,
    apply_type: 'พิจารณารายบุคคล',
    timeStart: '13.30',
    timeEnd: '20:00',
    dayStart: "2023-10-12",
    dayEnd: "2023-10-12",
    dayWork: 1,
    hourWorK: 8,
    pay: 48,
    position: 'พนักงานซักผ้า',
    img: 'burgerking.png',
    avg_score: 7.3,
    type_job: 'รับจ้างทั่วไป',
    amountEmp: 20,
    job_scope: "1.) ซักผ้าที่ตากไว้หลังร้าน 10 ถัง\n2.) นำผ้าที่ซักแล้วไปตากที่ปทุมธานี",
    job_info: "1.) แต่งการด้วยชุดนักบิน F16\n2.) นำใบอนุญาติซักผ้ามาด้วย\n3.) มีข้าวกลางวันฟรี",
    img: 'burgerking.png',
    address: "75/77 ซอยฉลองกรุง 29",
    tumbon: "ตำบลลำปลาทิว",
    amper: "ลาดกระบัง",
    province: "กรุงเทพมหานคร",
    zip_code: 12345,
    phone: '089991239',
    email: 'demo@ttjob.com',
    more_contact: 'Line: user123\nFacebook: user12345',
    com_confirm: true,
    emp_confirm: true,
}

export default function ViewJobDetailScreen({ navigation, route }) {
    const user = useSelector((state) => state.user[0]);
    console.log("MyUser",user);
    const [info, setInfo] = React.useState([]);
    // console.log("INFO:", info);
    const viewItem = route.params.view;
    console.log("View:", viewItem);
    const [location, setLocation] = React.useState([]);
    const [address, setAddress] = React.useState([]);
    React.useEffect(() => {
        axios.get('http://127.0.0.1:5000/map/?name=' + viewItem.companyName)
            .then((res) => {(setLocation(res.data)); console.log(res.data);})
            .catch((err) => console.log(err));

        axios.get('http://127.0.0.1:5000/job/jobInfo/'+viewItem.job_id)
            .then((res) => {setInfo(res.data.jobInfo); setAddress(res.data.address);})
            .catch((err) => console.log(err));
        console.log(address);
    }, []);

    // console.log("view :", viewItem);
    const dayStart = new Date(info.day_start);
    const dayEnd = new Date(info.day_end);
    function onRegionChance(region) {
        console.log(region);
    }

   async function apply(){
        const form = {
            job_id: viewItem.job_id,
            emp_id: user.emp_id,
            apply_type: viewItem.apply_type
        };
       const res = await axios.post('http://127.0.0.1:5000/apply/', form);
       console.log(res.data);
       if (res.data.status){
            Alert.alert("สมัครงานเรียบร้อย");
       }else{
            if (res.data.message === "Apply failed registed"){
                Alert.alert("คุณสมัครงานนี้แล้ว");
            }else{
                Alert.alert("เกิดข้อผิดพลาดค่ะ");
            }
            
       }

    }


    return (
        <View style={[styles.contianer]}>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }}
                con
            >
                <View style={[styles.titile]}>
                    <Image style={[styles.logo]} source={{ uri: viewItem.image_company }} />
                    <Text style={{ fontSize: width / 14.4, fontWeight: '700' }}>{viewItem.companyName}</Text>
                </View>
                <View style={[styles.title_info]}>
                    <Text style={styles.text_titleinfo}>ตำแหน่ง: {viewItem.position} รับ {info.emp_amount} คน</Text>
                    <Text style={styles.text_titleinfo}>รายได้: {viewItem.pay} ต่อ/ชั่วโมง</Text>
                    <Text style={styles.text_titleinfo}>รายได้รวม {info.working_hours * viewItem.pay} บาท</Text>
                    <Text style={styles.text_titleinfo}>การสมัคร: {viewItem.apply_type == 1 ? 'สมัครแล้วรับเลย' : 'พิจารณารายบุคคล'}</Text>
                    <Text style={styles.text_titleinfo}>ประเภทงาน: {viewItem.bussines_type}</Text>
                </View>

                <View style={[styles.deatilBox]}>
                    <Text style={{ fontSize: width / 14, fontWeight: '700' }}>
                        รายละเอียดงาน
                    </Text>
                    <View style={{ marginHorizontal: 10 }}>
                        <Text style={{ fontSize: width / 21.7 }}>
                            วันที่เริ่มงาน: {globalFunction.getDay(dayStart.getDay())} {dayStart.getDate()} {
                                globalFunction.getMonth(dayStart.getMonth())} {dayStart.getFullYear() + 543}
                        </Text>
                        <Text style={{ fontSize: width / 21.7 }}>
                            ถึง: {globalFunction.getDay(dayEnd.getDay())} {dayEnd.getDate()} {
                                globalFunction.getMonth(dayEnd.getMonth())} {dayEnd.getFullYear() + 543}
                        </Text>
                        <Text style={{ fontSize: width / 21.7 }}>
                            เวลาทำงาน: {viewItem.day_work} วัน
                        </Text>
                        <Text style={{ fontSize: width / 21.7 }}>
                            เวลาทำงาน: {viewItem.time_start} - {viewItem.time_end}
                        </Text>
                        <View style={{ marginVertical: 7 }}>
                            <Text style={{ fontSize: width / 19.7, fontWeight: '700' }}>
                                ขอบเขตงาน:
                            </Text>
                            <Text style={{ marginHorizontal: 5 }}>
                                {info.job_scope}
                            </Text>
                        </View>
                        <View style={{ marginVertical: 7 }}>
                            <Text style={{ fontSize: width / 19.7, fontWeight: '700' }}>
                                ข้อมูลการทำงาน:
                            </Text>
                            <Text style={{ marginHorizontal: 5 }}>
                                {info.job_infomation}
                            </Text>
                        </View>
                        <View style={{ marginVertical: 7 }}>
                            <Text style={{ fontSize: width / 19.7, fontWeight: '700' }}>
                                ช่องทางการติดต่อ:
                            </Text>
                            <Text style={{ marginHorizontal: 5 }}>
                                เบอร์โทรศัพท์: {user.phone}
                            </Text>
                            <Text style={{ marginHorizontal: 5 }}>
                                อีเมล: {user.email}
                            </Text>
                            {/* <Text style={{ marginHorizontal: 5 }}>
                                {detail.more_contact}
                            </Text> */}
                        </View>
                        <View style={{ marginVertical: 7 }}>
                            <Text style={{ fontSize: width / 19.7, fontWeight: '700' }}>
                                สถานที่ทำงาน:
                            </Text>
                            <Text style={{ marginHorizontal: 5 }}>
                                {detail.address} {detail.tumbon} {detail.amper}
                                {detail.province} {detail.zip_code}
                                {/* {location.name} */}
                            </Text>
                            <View style={{ marginVertical: 10 }}>
                                <MapView style={[styles.mapView]}
                                    onRegionChange={onRegionChance}
                                    showsUserLocation={true}
                                    provider={PROVIDER_GOOGLE}
                                    initialRegion={{
                                        latitude: location.lat,
                                        longitude: location.lng
                                    }}
                                    region={{
                                        latitude: location.lat,
                                        longitude: location.lng
                                    }}
                                >
                                    <Marker title="You"
                                        coordinate={{
                                        latitude: location.lat,
                                        longitude: location.lng
                                        }}
                                    />
                                </MapView>

                            </View>
                            <View style={{ marginVertical: 10 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Checkbox value={false}
                                        style={{
                                            padding: width / 36
                                        }}
                                    />
                                    <Text
                                        style={{
                                            marginHorizontal: width / 29.7,
                                            fontSize: width / 24.5
                                        }}>
                                        ยอมรับเงื่อนไขและนโยบายการสมัครงาน
                                    </Text>
                                </View>
                                <Text style={{
                                    textDecorationLine: 'underline',
                                    marginHorizontal: width / 11.9, color: '#0102ff'
                                }}>
                                    อ่านเงื่อนไขและนโยบาย
                                </Text>
                                <Button 
                                    title={"สมัครงาน"} style={{
                                        marginVertical: 10
                                    }} 
                                    onPress={() =>{
                                        apply();
                                    }}
                                />
                            </View>
                        </View>
                    </View>
                </View>
            </ScrollView>

        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
    },
    logo: {
        width: 250,
        height: 250,
        padding: width / 50,
        marginVertical: height / 22
    },
    titile: {
        alignItems: 'center',
        marginVertical: 10,
    },
    title_info: {
        padding: 10,
        marginHorizontal: 10,
        backgroundColor: '#D9D9D9',
        borderRadius: 5
    },
    text_titleinfo: {
        fontSize: width / 21.8
    },
    deatilBox: {
        marginHorizontal: 10,
    },
    mapView: {
        width: width - 50,
        height: 300
    }
})