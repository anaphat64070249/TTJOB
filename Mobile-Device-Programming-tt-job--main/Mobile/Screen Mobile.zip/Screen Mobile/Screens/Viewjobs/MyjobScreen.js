import React from "react";
import { View, Text, Image, StyleSheet, ScrollView, FlatList, RefreshControl } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import { useDispatch } from "react-redux";
import * as store from '../../store/store'
import { WorkingJob, ApplyJob } from "../../componeent/ListComponent";
import axios from "axios";
import { useSelector } from "react-redux";
// import * as ListJob from '../../componeent/ListComponent';

const demo1 = {
    com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
    com_id: 10000000,
    apply_type: 'พิจารณารายบุคคล',
    timeStart: '13.30',
    timeEnd: '20:00',
    dayWork: 1,
    pay: 48,
    position: 'พนักงานซักผ้า',
    img: 'burgerking.png',
    avg_score: 7.3,
    dayStart: "2023-10-12",
    dayEnd: "2023-10-12",
    com_confirm: true,
    emp_confirm: true,
}

const listApply = [
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'สมัครแล้วรับทันที',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3,
        dayStart: "2023-10-12",
        dayEnd: "2023-10-12",
        com_confirm: true,
        emp_confirm: true,
    },
    {
        com_name: 'เบอร์เกอร์คิง BigC ลาดกระบัง',
        com_id: 10000000,
        apply_type: 'พิจารณารายบุคคล',
        timeStart: '13.30',
        timeEnd: '20:00',
        dayWork: 1,
        pay: 48,
        position: 'พนักงานซักผ้า',
        img: 'burgerking.png',
        avg_score: 7.3,
        dayStart: "2023-10-12",
        dayEnd: "2023-10-12",
        com_confirm: false,
        emp_confirm: false,
    },

]

export default function MyjobScreen({ navigation }) {
    const [apply, setApply] = React.useState([]);
    const user = useSelector(state => state.user[0]);
    const [refreshing, setRefreshing] = React.useState(false);
    const [loading, setLoading] = React.useState(true);
    const [work_now, setWork_now] = React.useState([])
    React.useEffect(() => {
        axios.get('http://127.0.0.1:5000/job/applyed/' + user.emp_id)
            .then((res) => {
                setApply(res.data);
                console.log("MYaspplsys:",res.data);
                console.log(3);
                axios.get('http://127.0.0.1:5000/job/doing/' + user.emp_id)
                .then((res) => {
                    setWork_now(res.data);
                    console.log("workss11", res.data[1]);
                    console.log(9);
                });
            });
        console.log(apply);
        console.log("MYDOING",work_now[0]);
    }, []);

    const onRefresh = React.useCallback(() => {
        console.log(refreshing);
        setRefreshing(true);

        axios.get('http://127.0.0.1:5000/job/applyed/' + user.emp_id)
            .then((res) => {
                setApply(res.data);
                console.log("MYapplsys:",res.data);
                console.log("ww");
                axios.get('http://127.0.0.1:5000/job/doing/' + user.emp_id)
                .then((res) => {
                    setWork_now(res.data);
                    console.log("MYDOIsNssGs", res.data[1]);
                });
            }).finally(() => {
                setLoading(false);
            });

        setTimeout(() => {
            setRefreshing(false);
        }, 3000);

    }, []);

    function render(item) {
        return <ApplyJob data={item} user={user} navigation={navigation} />
    }

    if ((apply[0] === undefined )|| work_now[0] === undefined) {
        return (
            <View style={{ flex: 1 }}>
                <Text style={{
                    fontSize: 35, fontWeight: '700',
                    alignItems: 'center', alignSelf: 'center', marginTop: 55
                }}>
                    Loading...
                </Text>
            </View>
        )
    }

    return (
        <View style={[styles.container]}>
            <ScrollView nestedScrollEnabled={true}
                refreshControl={
                    <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
                }
            >
                <View>
                    <Text style={{ fontSize: width / 14, fontWeight: '700' }}>
                        งานที่กำลังทำ
                    </Text>
                    <View style={{}}>
                        <View style={{ marginVertical: 10, }}>
                            {
                                work_now[0].isDoing ? <WorkingJob data={work_now[1]} navigation={navigation} /> :
                                    <Text style={{ fontSize: 26, fontWeight: '600', textAlign: 'center', alignSelf: 'center' }}>ไม่มีงาน</Text>
                            }

                        </View>
                    </View>
                </View>
                <View>
                    <View style={{}}>
                        <Text style={{ fontSize: width / 14, fontWeight: '700' }}>
                            งานที่สมัคร
                        </Text>
                    </View>
                    <View style={{}}>
                        {
                            apply[0].is_apply ? <FlatList data={apply[1]} renderItem={render} nestedScrollEnabled={true} />: 
                            <Text style={{ fontSize: 26, fontWeight: '600', textAlign: 'center', alignSelf: 'center' }}>
                                ไม่มีงาน
                            </Text>
                        }
                        
                    </View>
                </View>
            </ScrollView>
        </View>

    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
    }
});