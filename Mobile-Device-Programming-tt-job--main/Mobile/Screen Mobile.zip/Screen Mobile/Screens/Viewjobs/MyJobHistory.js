import React from "react";
import { View, Text, ScrollView, Image, StyleSheet, SectionList, Modal, RefreshControl } from "react-native";
import { Button } from "react-native-elements";
import { Dimensions } from "react-native";
import { ListJobHisroty } from "../../componeent/JobHistory/listJobHistory";
const { width, height } = Dimensions.get('window');
import { useDispatch } from "react-redux";
import * as store from '../../store/store'
import axios from "axios";
import { useSelector } from "react-redux";

const user = {
    emp_id: 10000000,
    image_profile: 'https://www.siamsporttalk.com/media/bearleague/bl16678954161533.png',
    experience_hour: 82,
    avg_score: 7.5,
    firstName: '',
    lastName: ''
}

const historyJob = [
    {
        title: 'ร้านอาหาร',
        allHour: 20,
        data: [
            {
                position: "พนักงานครัว",
                hour: 7,
                score: 6
            },
            {
                position: "พนักงานเสิรฟอาหาร",
                hour: 7,
                score: 6.5
            },
            {
                position: "พนักงานทำความสะอาด",
                hour: 6,
                score: 7
            },
        ]
    },
    {
        title: 'โรงงานอุตสาหกรรม',
        allHour: 41,
        data: [
            {
                position: "ช่างไฟฟ้า",
                hour: 21,
                score: 8.5
            },
            {
                position: "ช่างประปา",
                hour: 6,
                score: 6
            },
            {
                position: "ช่างเชื่อม",
                hour: 14,
                score: 7
            },
        ]
    },
]


export default function MyJobHistory({ navigation }) {
    const [loading, setLoading] = React.useState(true);
    const [datas, setData] = React.useState([]);
    const user = useSelector((state) => state.user[0]);
    const [refreshing, setRefreshing] = React.useState(false);

    React.useState(() => {
        console.log('http://127.0.0.1:5000/history/get/' + user.emp_id);
        axios.get('http://127.0.0.1:5000/history/get/' + user.emp_id)
            .then((res) => {
                setLoading(true);
                setData(res.data);
                console.log(loading);
                console.log("DATA HISTORY: ",res.data[0]);
            }).catch(error => console.log(error))
            .finally(() =>{
                setLoading(false);
            })
    })


    const dispatch = useDispatch();

    const onRefresh = React.useCallback(() => {
        console.log(refreshing);
        setRefreshing(true);
        axios.get('http://127.0.0.1:5000/history/get/' + user.emp_id)
        .then((res) => {
            setLoading(true)
            setData(res.data);
            console.log(res.data[0]);
        }).finally(() =>{
            setLoading(false);
        });
        setTimeout(() => {
            setRefreshing(false);
        }, 4000);
        
    });

    function setHeader(bool) {
        dispatch(store.setHeader(bool))
    }

    function HeaderSection(data) {
        const item = data.section;
        return (
            <View style={{ marginVertical: 10 }}>
                <Text style={{ fontSize: width / 19.4, fontWeight: '600' }}>
                    {item.title}: รวม {item.all_work_hour} ชั่วโมง
                    {'\n'}
                    <Text
                        onPress={() => {
                            // setModal(true);
                            // setTitle(item.title);
                            console.log("title", item.title);
                            setHeader(false);
                            navigation.navigate('MyJobList', { title: item.title });
                        }}

                        style={{
                            backgroundColor: '#0100F0', padding: 5, color: "#fff",
                            fontSize: width / 22
                        }}
                    >
                        กดดูรายละเอียด
                    </Text>
                </Text>
            </View>
        )
    }

    function render(data) {
        const item = data.item;
        console.log(item);
        return (
            <View style={{ marginLeft: 7 }}>
                <Text style={{
                    fontSize: width / 26.4
                }}>
                    {item.position}: <Text style={{ color: '#EA8D02' }}>{item.work_hour} ชั่วโมง</Text> <Text style={{ color: '#003BAC' }}>คะแนนเฉลี่ย {item.avg_score} คะแนน</Text>
                </Text>
            </View>
        )
    }

    if (loading == true){
        return(
            <View style={[styles.contianer]}>
                <Text style={{
                    fontSize: width / 15,
                    alignSelf: 'center',
                    justifyContent: 'center',
                    marginTop: 35,
                }}>loading...</Text>
            </View>
        )
    }
    return (
        <View style={styles.contianer}>
            {
                datas == [] ? <View><Text>รอแปปนะ</Text></View> :
                    <ScrollView
                        refreshControl={
                            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
                        }
                    >
                        <View style={[styles.header, { alignItems: 'center', borderBottomWidth: 1 }]}>
                            <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_BgmS-IVX4raZJ8OJTJGIEpSJLhipNG6CIBkS4XUZrC93Ykj0wXDEHTh1Oszvbv3MmSU&usqp=CAU"}}
                                width={150} height={150}
                            />
                            <View style={{ alignSelf: 'center', marginVertical: 10 }}>
                                <Text style={{
                                    fontSize: width / 21.4,
                                    textAlign: 'center'
                                }}>
                                    {datas[0].firstName} {datas[0].lastName}
                                </Text>
                                <Text style={{
                                    fontSize: width / 21.4,
                                }}>
                                    🕐 ชั่วโมงการทำงานทั้งหมด: {datas[0].experience_hour} ชั่วโมง{'\n'}
                                    ⭐️ คะแนนการทำงานเฉลี่ย: {datas[0].avg_score} คะแนน
                                </Text>
                            </View>
                        </View>
                        <View>
                            <Text style={{
                                fontSize: width / 14.5,
                                fontWeight: '800',
                                textAlign: 'center'
                            }}>
                                ประวัติการทำงาน
                            </Text>
                            <View style={{
                                padding: 10,
                                marginLeft: width / 24.4
                            }}>
                                <SectionList scrollToOverflowEnabled={false} scrollEnabled={false}
                                    sections={datas[1]}
                                    renderSectionHeader={HeaderSection}
                                    renderItem={render}
                                    keyExtractor={(item, index) => item + index}
                                />
                            </View>
                        </View>
                    </ScrollView>
            }


        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1
    },
    header: {
        padding: 10,
        marginVertical: 10
    }
})