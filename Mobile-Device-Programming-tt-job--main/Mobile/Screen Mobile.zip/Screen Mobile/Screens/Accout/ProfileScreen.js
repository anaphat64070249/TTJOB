import React from "react";
import { View, Text, StyleSheet, Image, ScrollView } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import * as globalFunction from '../../globalFunction';
import { useSelector } from "react-redux";
import axios from "axios";

// const user = {
//     personal_infoID: 10000000,
//     emp_id: 10000000,
//     phone: '0981122334',
//     email: 'demo1@ttjob.com',
//     firstName: 'คาเทโอรุ',
//     lastName: 'มิโตมะ',
//     nickName: 'มิโตะ',
//     age: 20,
//     gender: 'ชาย',
//     personal_id: '0999200001244',
//     date_of_birth: '2002-11-11',
//     weight: 65,
//     height: 170,
//     occupation: 'นักเรียน/นักศึกษา',
//     education: 'มัธยมศึกษาตอนปลาย',
//     abilities: 'ทักษะด้านคอมพิวเตอร์/IT',
//     image_profile: 'https://www.siamsporttalk.com/media/bearleague/bl16678954161533.png',
//     address_code: 10000123,
//     district: 'เขตพระนคร',
//     tumbon: 'สำราญราษฎร์',
//     province: 'กรุงเทพมหานคร',
//     zipCode: '10200',
//     address: 'สำราญราษฎร์ 12 บ้านเลขที่ 87/11',
//     intro_message: 'ฉันเป็นคนดี',
//     vehicle: 'รถจักรยานยนต์',
//     driver_license: 'มีใบขับขี่รถจักรยานยนต์',
//     experience_hour: 82,
//     avg_score: 7.5
// }

export default function ProfileScreen() {
    const [profile, setProfile] = React.useState([]);
    const [address, setAddeess] = React.useState([]);
    const user = useSelector((state) => state.user[0]);
    React.useEffect(() =>{
        // console.log('http://127.0.0.1:5000/emp/infoAndEmp/'+user.emp_id);
        axios.get('http://127.0.0.1:5000/emp/address/'+user.emp_id)
        .then((res) => {
            setAddeess(res.data);
            axios.get('http://127.0.0.1:5000/emp/infoAndEmp/'+user.emp_id)
            .then((res) => {setProfile(res.data)})
            .catch(err => console.log(err));
        })
        .catch(err => console.log(err));


    }, [])

    const date = new Date(profile.date_of_birth);

    return (
        <View style={[style.contianer]}>
            <ScrollView>
                <View style={{
                    padding: 5,
                    alignItems: 'flex-end'
                }}>
                    <Text style={{ fontSize: width / 19 }}>
                        แก้ไข ✏️
                    </Text>
                </View>
                <View>
                    <Image
                        source={{ uri: profile.image_profile }}
                        width={160} height={160}
                        style={{
                            alignSelf: 'center'
                        }}
                    />
                    <View style={{ alignSelf: 'center', marginVertical: 10 }}>
                        <Text style={{
                            fontSize: width / 21.4,
                        }}>
                            🕐 ชั่วโมงการทำงานทั้งหมด: {profile.experience_hour} ชั่วโมง{'\n'}
                            ⭐️ คะแนนการทำงานเฉลี่ย: {profile.avg_score} คะแนน
                        </Text>
                    </View>
                </View>
                <View style={{ marginTop: 12, marginHorizontal: width / 18, padding: 10 }}>
                    {/* <Text style={{
                        fontSize: width / 20.4
                    }}>
                        อีเมล: {user.email}{'\n'}
                        เบอร์โทรศัพท์: {user.phone}{'\n'}
                        ชื่อ-นามสกุล: {user.firstName} {user.lastName}{'\n'}
                        ชื่อเล่น: {user.nickName}{'\n'}
                        อายุ: {user.age} ปี{'\n'}
                        เพศ: {user.gender}{'\n'}
                        วันเกิด: {user.date_of_birth}{'\n'}
                        รหัสบัตรประชาชน: 1368987657789{'\n'}
                        น้ำหนัก: {user.weight} kg.{'\n'}
                        ส่วนสูง: {user.height} cm.{'\n'}
                        การศึกษา: {user.education}{'\n'}
                        อาชีพปัจจุบัน: {user.occupation}{'\n'}
                        ความสามารถ: {user.abilities}{'\n'}
                        ข้อความแนะนำตัว: {user.intro_message}{'\n'}
                        ที่อยู่: {user.address} {user.district} {user.tumbon} {user.province} {user.zipCode}{'\n'}
                        ยานพาหนะ: {user.vehicle}{'\n'}
                        ใบอนุญาตขับขี่: {user.driver_license}{'\n'}
                    </Text> */}
                    <Text style={{ fontSize: width / 20.4 }}>
                        <Text style={{ color: '#0010DD' }}>
                            อีเมล: <Text style={{ color: '#000' }}>{profile.email}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            เบอร์โทรศัพท์: <Text style={{ color: '#000' }}>{profile.phone}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ชื่อ-นามสกุล:
                            <Text style={{ color: '#000' }}> {profile.firstName} {profile.lastName}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ชื่อเล่น:
                            <Text style={{ color: '#000' }}> {profile.nickName}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            อายุ:
                            <Text style={{ color: '#000' }}> {profile.age} ปี</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            เพศ:
                            <Text style={{ color: '#000' }}> {profile.gender}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            วันเกิด:
                            <Text style={{ color: '#000' }}> {date.getDate()} {globalFunction.getMonth(date.getMonth())} {date.getFullYear() + 543}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            รหัสบัตรประชาชน:
                            <Text style={{ color: '#000' }}> {profile.personal_id}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            น้ำหนัก:
                            <Text style={{ color: '#000' }}> {profile.weight} kg.</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ส่วนสูง:
                            <Text style={{ color: '#000' }}> {profile.height} cm.</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            การศึกษา:
                            <Text style={{ color: '#000' }}> {profile.education}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            อาชีพปัจจุบัน:
                            <Text style={{ color: '#000' }}> {profile.occupation}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ความสามารถ:
                            <Text style={{ color: '#000' }}> {profile.abilities}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ข้อความแนะนำตัว:
                            <Text style={{ color: '#000' }}> {'\n'}{profile.intro_message}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ที่อยู่:
                            <Text style={{ color: '#000' }}>
                                {'\n'}{address.address} {address.district} {address.tumbon} {address.province} {address.zipCode}
                            </Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ยานพาหนะ:
                            <Text style={{ color: '#000' }}> {profile.vehicle}</Text>
                        </Text>{'\n'}
                        <Text style={{ color: '#0010DD' }}>
                            ใบอนุญาตขับขี่:
                            <Text style={{ color: '#000' }}> {profile.driver_license}</Text>
                        </Text>{'\n'}
                    </Text>
                </View>
            </ScrollView>
            <View style={{
                backgroundColor: '#01B495',
                padding: 10
            }}>
                <Text style={{ alignSelf: 'center', fontSize: 20, color: '#ffF' }}>
                    @ttjob.com
                </Text>
            </View>
        </View>
    )
}

const style = StyleSheet.create({
    contianer: {
        flex: 1,
    }
});