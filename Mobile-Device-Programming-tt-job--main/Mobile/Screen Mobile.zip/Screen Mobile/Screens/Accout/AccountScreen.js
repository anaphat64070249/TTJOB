import React from "react";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import { View, Text, StyleSheet, Image, ScrollView } from "react-native";
import { Button } from "react-native-elements";
import axios from "axios";
import { useSelector } from "react-redux";


// const account = {
//     emp_id: 10000000,
//     firstName: 'คนดี',
//     lastName: 'คนเดิม',
//     email: 'user1@ttjob.com',
//     phone: '0891112389',
//     status: 1,
//     image: ''
// }

export default function AccountScreen({navigation}) {
    const user = useSelector(state => state.user[0]);
    const [account, setAccount] = React.useState([]);

    React.useEffect(() =>{
        axios.get('http://127.0.0.1:5000/emp/infoAndEmp/'+user.emp_id)
        .then((res) => {setAccount(res.data)});
    });

    return (
        <View style={[styles.contianer]}>
            <ScrollView>
                <View style={{
                    justifyContent: 'center',
                    alignSelf: 'center',
                    marginVertical: 10
                }}>
                    <Image
                        source={{ uri: account.image_profile }}
                        width={200} height={200}
                    />
                </View>
                <View style={[styles.info_box]}>
                    <Text style={{
                        fontSize: width / 17.5,
                        marginHorizontal: width / 18,
                        padding: width / 22
                    }}>
                        เลขที่ผู้ใช้: {account.emp_id}{'\n'}
                        ชื่อ: {account.firstName} {account.lastName}{'\n'}
                        เบอร์โทรศัพท์: {account.phone}{'\n'}
                        อีเมล: {account.email}{'\n'}
                        รหัสผ่าน: ********{'\n'}
                        สถานะผู้ใช้: {account.user_status == 1 ? "อนุมัติแล้ว" : "ถูกระงับการใช้งานชั่วคราว"}
                    </Text>
                    <View style={[styles.col]}>
                        <Button title={"เปลี่ยนรหัสผ่าน"}
                            style={[styles.button]}
                            buttonStyle={{ 
                                backgroundColor: '#0E0B9F',
                                borderRadius: width / 45,
                            }}
                        />
                        <Button title={"ยกเลิกสมาชิก"}
                            style={[styles.button]}
                            buttonStyle={{
                                backgroundColor: '#9F0B1D',
                                borderRadius: width / 45
                            }}

                        />
                    </View>
                    <Button title={"ออกจากระบบ"}
                        style={{
                            padding: 10,
                            width: width / 1.4,
                            marginLeft: width / 20
                        }}
                        buttonStyle={{
                            backgroundColor: '#9F6D0B',
                            borderRadius: width / 45
                        }}
                    />
                </View>
            </ScrollView>

        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1,
        padding: 10
    },
    info_box: {
        backgroundColor: '#D9D9Db',
        marginVertical: height / 63,
        alignSelf: 'center',
        borderRadius: width / 32
    },
    button: {
        padding: 10,
        marginHorizontal: 2,

    },
    col: {
        flexDirection: 'row',
        marginLeft: width / 24
    }
});