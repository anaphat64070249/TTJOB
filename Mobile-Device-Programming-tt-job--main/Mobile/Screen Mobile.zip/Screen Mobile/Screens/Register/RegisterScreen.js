import React from "react";
import {
    View, StyleSheet, Text, SafeAreaView, ScrollView,
    FlatList, TextInput, SectionList,
    Platform, Alert, Image,
} from "react-native";
import Checkbox from 'expo-checkbox';
import { Button } from 'react-native-elements';
import axios from "axios";
import SelectDropdown from 'react-native-select-dropdown';
import { AntDesign } from '@expo/vector-icons';
import { Dimensions } from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import * as getAddress from "../../model/address";
import * as getPersonalModel from "../../model/personalModel";
import { IconButton } from "react-native-paper";
import * as ImagePicker from 'expo-image-picker';
const { width, height } = Dimensions.get('window');

const FormatDate = (data) => {
    let dateTimeString =
        data.getDate() +
        ' / ' +
        (data.getMonth() + 1) +
        ' / ' +
        (data.getFullYear() + 543) +
        ' '
    return dateTimeString; // It will look something like this 3-5-2021 16:23 
};

const genderList = ["ชาย", "หญิง", "LGBTQ+", "ไม่ประสงให้ข้อมูล"];

export default function RegisterScreen({navigation}) {
    const [phone, setPhone] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('')
    const [firstName, setFirstName] = React.useState('');
    const [lastName, setLastName] = React.useState('');
    const [nickNmae, setNickName] = React.useState('');
    const [gender, setGender] = React.useState('');
    const [date, setDate] = React.useState('');
    const [age, setAge] = React.useState(0);
    const [address, setAddress] = React.useState('');
    const [province, setProvice] = React.useState('');
    const [amper, setAmper] = React.useState('');
    const [tumbon, setTumbon] = React.useState('');
    const [zipCode, setZipCode] = React.useState('');
    const [weight, setWeight] = React.useState(0);
    const [height, setHeight] = React.useState(0);
    const [education, setEducation] = React.useState('');
    const [occupation, setOccupation] = React.useState('');
    const [allAbilities, setAllAbilities] = React.useState('');
    const [abilities, setAbilities] = React.useState('');
    const [intro_mes, setIntro_mes] = React.useState('');
    const [vihecle, setvihecle] = React.useState('');
    const [driving_license, setDriving_license] = React.useState('');
    const [personal_id, setPersonal_id] = React.useState('');

    // image
    const [img_personalId, setImg_PersonalID] = React.useState(null)
    const [img_Profile, setImg_Profile] = React.useState(null)

    // date time
    const [dateSelect, setDateSelect] = React.useState("")
    const [openDatePicker, setOpenDatePicker] = React.useState(false);
    //checkBox
    const [isConfirm, setIsConfirm] = React.useState(false);
    const removeItem = (del) => {
        let arr = allAbilities.split(',').filter(function (item) {
            return item !== del;
        })
        console.log(arr.toString());
        setAllAbilities(arr.toString === '' ? "" : arr.toString());
    };
    // Image Picker
    async function getPermission() {
        if (Platform.OS !== 'web') {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== 'granted') {
                Alert.alert("Access Denied!")
                return <View />
            }
        }
    }
    React.useEffect(() => {
        getPermission();
    }, []);

    async function pinckImageID() {
        setImg_PersonalID(null);
        let result = await ImagePicker.launchImageLibraryAsync({
            // mediaTypes: ImagePicker.MediaTypeOptions.Images,
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true
        });
        if (!result.canceled) {
            setImg_PersonalID(result);
        }
    }
    async function pinckImageProfile() {
        setImg_Profile(null);
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true
        });
        if (!result.canceled) {
            setImg_Profile(result);
        }
    }

    async function submit() {
        const form = new FormData();
        form.append("phone", phone);
        form.append("email", email);
        form.append("password", password)
        form.append('firstName', firstName);
        form.append("lastName", lastName);
        form.append("nickName", nickNmae);
        form.append("gender", gender);
        form.append("age", Number(age))
        form.append("date_of_birth", date);
        form.append("address", address);
        form.append("weight", Number(weight));
        form.append("height", Number(height));
        form.append("occupation", occupation);
        form.append("education", education);
        form.append("abilities", abilities);
        form.append("personal_id", personal_id);
        form.append("intro_message", intro_mes);
        form.append("vehicle", vihecle);
        form.append("driver_license", driving_license);
        form.append("district", amper.name_th);
        form.append("tumbon", tumbon.name_th);
        form.append("province", province.name_th);
        form.append("zipCode", zipCode);

        // Thank source code in https://stackoverflow.com/questions/42521679/how-can-i-upload-a-photo-with-expo
        // for help me upload file image to server;

        let localUriProfile = img_personalId.uri;
        let filename_profile = localUriProfile.split('/').pop();
        let match_profile = /\.(\w+)$/.exec(filename_profile);
        let type_profile = match_profile ? `image/${match_profile[1]}` : `image`;
        form.append('image_profile', { uri: localUriProfile, name: filename_profile, type_profile });

        let localUriPersonal_id = img_personalId.uri;
        let filename_personalId = localUriPersonal_id.split('/').pop();
        let match_Personal_id = /\.(\w+)$/.exec(filename_personalId);
        let type_Personal_id = match_Personal_id ? `image/${match_Personal_id[1]}` : `image`;
        form.append('image_personalID', { uri: localUriPersonal_id, name: filename_personalId, type_Personal_id });

        // await fetch("http://127.0.0.1:5000/user/test", {
        //     method: 'POST',
        //     body: form,
        //     headers: {
        //       'content-type': 'multipart/form-data',
        //     },
        // });
        const register = await axios.post('http://127.0.0.1:5000/user/create', form);
        console.log(register.data);


    };

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView style={styles.scrollView} >
                <View style={styles.form}>
                    <View style={[styles.inputItem]}>
                        <Text style={[styles.textLabel]}>เบอร์โทรศัพท์</Text>
                        <TextInput placeholder="0123456789" style={[styles.textInput]}
                            value={phone} onChangeText={setPhone}
                            keyboardType="phone-pad"
                        />
                    </View>

                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อีเมล</Text>
                        <TextInput placeholder="demo@ttjob.com" style={[styles.textInput]}
                            value={email} onChangeText={setEmail}
                            keyboardType='email-address' />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>รหัสผ่าน</Text>
                        <TextInput placeholder="**************" style={[styles.textInput]}
                            value={password} onChangeText={setPassword}
                        />
                    </View>

                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ชื่อจริง</Text>
                        <TextInput placeholder="คนดี" style={[styles.textInput]}
                            value={firstName} onChangeText={setFirstName} />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>นามสกุล</Text>
                        <TextInput placeholder="รักงาน" style={[styles.textInput]}
                            value={lastName} onChangeText={setLastName} />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ชื่อเล่น</Text>
                        <TextInput placeholder="สมชาย" style={[styles.textInput]}
                            value={nickNmae} onChangeText={setNickName} />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อายุ</Text>
                        <TextInput style={[styles.textInput, { width: width / 3.2 }]}
                            value={age} onChangeText={setAge}
                            keyboardType="name-phone-pad"
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>เพศ</Text>
                        <SelectDropdown data={genderList}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem
                            }}
                            rowTextForSelection={(item, index) => {
                                return item
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem, index);
                                setGender(selectedItem);
                            }}
                            defaultButtonText="เลือกเพศ"
                            buttonStyle={styles.selectionBTN}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>วันเกิด</Text>
                        <Button title={typeof dateSelect === "object" ? FormatDate(dateSelect) : "Day / Month / Year"}
                            buttonStyle={{ backgroundColor: '#fff' }}
                            titleStyle={{
                                color: "#000",
                            }}
                            containerStyle={styles.date}
                            onPress={() => { setOpenDatePicker(true) }}
                        />
                        <DateTimePickerModal
                            style={styles.date}
                            isVisible={openDatePicker}
                            mode="date"
                            onConfirm={(dates) => {
                                setDate(dates)
                                setDateSelect(dates)
                                setOpenDatePicker(false)
                                console.log(dates);
                            }}
                            onCancel={() => {
                                setOpenDatePicker(false)
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ที่อยู่</Text>
                        <TextInput placeholder=""
                            style={[styles.textInput, { height: 100, textAlignVertical: 'top' }]}
                            value={address} onChangeText={setAddress}
                            multiline={true}
                            numberOfLines={5}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>จังหวัด</Text>
                        <SelectDropdown data={getAddress.GetProvice()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem.name_th;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item.name_th;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log({ province_id: selectedItem.id, name_th: selectedItem.name_th });
                                setProvice({ province_id: selectedItem.id, name_th: selectedItem.name_th })
                            }}
                            defaultButtonText="เลือกจังหวัด"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อำเภอ/เขต</Text>
                        <SelectDropdown data={getAddress.GetAmper(province.province_id)}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem.name_th;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item.name_th;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log({ amphure_id: selectedItem.id, name_th: selectedItem.name_th });
                                setAmper({ amphure_id: selectedItem.id, name_th: selectedItem.name_th })
                            }}
                            defaultButtonText="เลือกอำเภอ/เขต"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ตำบล/แขวง</Text>
                        <SelectDropdown data={getAddress.GetTumbon(amper.amphure_id)}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem.name_th;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item.name_th;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log({ tumbon_id: selectedItem.id, name_th: selectedItem.name_th, zip_code: selectedItem.zip_code });
                                setTumbon({ tumbon_id: selectedItem.id, name_th: selectedItem.name_th, zip_code: selectedItem.zip_code })
                                setZipCode(selectedItem.zip_code)
                            }}
                            defaultButtonText="เลือกตำบล/แขวง"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>รหัสไปรษณีย์</Text>
                        <TextInput style={[styles.textInput, { width: width / 3.2, backgroundColor: '#EDEDED', textAlign: 'center' }]}
                            value={zipCode.toString()} editable={false} />
                    </View>
                    <View style={[container.container]}>
                        <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                            <Text style={[styles.textLabel]}>ส่วนสูง (cm)</Text>
                            <TextInput style={[styles.textInput,
                            {
                                width: width / 3.2,
                                textAlign: 'center'
                            }]}
                                value={height} onChangeText={setHeight}
                            // keyboardType={Platform.OS === 'android' ? "numeric" : "decimal-pad"}
                            />
                        </View>
                        <View style={[styles.inputItem, { marginTop: 7.3, marginHorizontal: width / 16.4 }]}>
                            <Text style={[styles.textLabel]}>น้ำหนัก (kg)</Text>
                            <TextInput style={[styles.textInput,
                            {
                                width: width / 3.2,
                                textAlign: 'center'
                            }]}
                                value={weight} onChangeText={setWeight}
                            // keyboardType={Platform.OS === 'android' ? "numeric" : "decimal-pad"} 
                            />
                        </View>
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ระดับการศึกษา</Text>
                        <SelectDropdown data={getPersonalModel.getListEducationSelector()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem);
                                setEducation(selectedItem)
                            }}
                            defaultButtonText="เลือกระดับการศึกษา"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อาชีพปัจจุบัน</Text>
                        <SelectDropdown data={getPersonalModel.getListOccupationSelector()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem);
                                setOccupation(selectedItem)
                            }}
                            defaultButtonText="เลือกอาชีพ"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>

                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ความสามารถ</Text>
                        <SelectDropdown data={getPersonalModel.getListAbilitiesSelector()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem);
                                setAbilities(selectedItem)
                            }}
                            defaultButtonText="เลือกความสามารถ"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                        <Button title={"เพิ่ม"}
                            buttonStyle={{
                                backgroundColor: '#3A976B',
                                width: width / 4.71,
                                borderRadius: 5
                            }}
                            style={{ marginTop: 10 }}
                            onPress={() => {
                                if (allAbilities === '') {
                                    console.log("All abilities: ", abilities);
                                    setAllAbilities(abilities)
                                } else {
                                    console.log("All abilities: ", allAbilities + "," + abilities);
                                    setAllAbilities(allAbilities + "," + abilities)
                                }
                            }}
                        />
                    </View>
                    {/* list abilities */}
                    <View style={[styles.inputItem, { marginTop: 7.3, }]}>
                        <FlatList data={allAbilities === '' ? [] : allAbilities.split(',')}
                            renderItem={(data) => {
                                return (
                                    <View data={data} style={[styles.flatListItem]} >
                                        <View style={{ flexDirection: 'row', }}>
                                            <View style={{
                                                padding: width / 26, alignSelf: 'flex-start',
                                                alignContent: 'flex-start'
                                            }}>
                                                <Text style={{
                                                    fontSize: width / 22.19,
                                                    textAlign: 'center',
                                                }}>
                                                    {data.item}
                                                </Text>
                                            </View>
                                            <View style={{

                                            }}>
                                                <IconButton
                                                    icon={"close-circle-outline"}
                                                    iconColor="#FF0108"
                                                    size={width / 13.35}
                                                    style={{
                                                        marginTop: 'auto',
                                                        backgroundColor: '#fff',
                                                        alignItems: 'flex-end'
                                                    }}
                                                    onPress={() => {
                                                        console.log(data.index, data.item);
                                                        removeItem(data.item)
                                                    }}
                                                />
                                            </View>
                                        </View>
                                    </View>
                                )
                            }}
                        >
                        </FlatList>
                    </View>

                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ข้อความแนะนำตัว</Text>
                        <TextInput placeholder=""
                            style={[styles.textInput, { height: 100, textAlignVertical: 'top' }]}
                            value={intro_mes} onChangeText={setIntro_mes}
                            multiline={true}
                            numberOfLines={5}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ยานพาหนะ</Text>
                        <SelectDropdown data={getPersonalModel.getVihecleSelectot()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem);
                                setvihecle(selectedItem)
                            }}
                            defaultButtonText="เลือกยานพาหนะ"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>ใบอนุญาตขับขี่</Text>
                        <SelectDropdown data={getPersonalModel.getDrivingLicenseSelector()}
                            buttonTextAfterSelection={(selectedItem, index) => {
                                return selectedItem;
                            }}
                            rowTextForSelection={(item, index) => {
                                return item;
                            }}
                            onSelect={(selectedItem, index) => {
                                console.log(selectedItem);
                                setDriving_license(selectedItem)
                            }}
                            defaultButtonText="เลือกใบอนุญาตขับขี่"
                            buttonStyle={styles.selectLocation}
                            renderDropdownIcon={isOpne => {
                                return <AntDesign name={isOpne ? "caretup" : "caretdown"} size={24} color="black" />
                            }}
                        />
                    </View>
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>หมายเลขบัตรประชาชน</Text>
                        <TextInput placeholder="123xxxxxxxxxx" style={[styles.textInput]}
                            value={personal_id} onChangeText={setPersonal_id} />
                    </View>

                    {/* อัพโหลดรูปสำเนาบัตร ปปช */}
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อัพโหลดสำเนาบัตรประชาชน</Text>
                        <Button title={'เลือกรูปภาพ'} onPress={() => { pinckImageID() }}
                            buttonStyle={{
                                backgroundColor: '#B2E1FC',
                                width: width / 2,
                                borderRadius: 5
                            }}
                            titleStyle={{ color: '#000' }}
                        />
                        {img_personalId && <Image source={{ uri: img_personalId.uri }} style={container.imgUpload} />}
                    </View>

                    {/* อัพโหลดรูปโปรไฟล์ */}
                    <View style={[styles.inputItem, { marginTop: 7.3 }]}>
                        <Text style={[styles.textLabel]}>อัพโหลดรูปโปรไฟล์</Text>
                        <Button title={'เลือกรูปภาพ'} onPress={() => { pinckImageProfile() }}
                            buttonStyle={{
                                backgroundColor: '#B2E1FC',
                                width: width / 2,
                                borderRadius: 5
                            }}
                            titleStyle={{ color: '#000' }}
                        />
                        {img_Profile && <Image source={{ uri: img_Profile.uri }} style={container.imgUpload} />}
                    </View>
                    <View style={[styles.inputItem, { marginTop: 24.3 }]} >
                        <View style={{ flexDirection: 'row' }}>
                            <Checkbox value={isConfirm}
                                onValueChange={(val) => {
                                    console.log(val);
                                    setIsConfirm(val);
                                }}
                                style={{ padding: 13, width: width / 80 }}
                            />
                            <Text style={{ fontSize: width / 22.2, marginHorizontal: 8, marginTop: - (height / 136) }}>ฉันยอมรับเงื่อนไขและนโยบานการสมัครสมาชิก</Text>
                        </View>
                        <Text style={{ fontSize: width / 22.2, color: '#0103da', marginHorizontal: 37, textDecorationLine: 'underline' }}>
                            อ่านเงื่อนไขและนโยบาย
                        </Text>


                    </View>
                    <View>
                        <Button title={"สมัครสมาชิก"} disabled={!isConfirm}
                            onPress={() => {
                                // Alert.alert("ระบบกำลังสมัครสมาชิก กรุณารอสักครู่คะ")
                                // Alert.alert(
                                //     'ระบบกำลังสมัครสมาชิก',
                                //     'My Alert Msg',
                                //     [
                                //         {
                                //             text: 'ยืนยัน',
                                //             onPress: () => {
                                //                 Alert.alert('ระบบกำลังสมัครสมาชิก กรุณารอสักครู่คะ',
                                //                     [
                                //                         {
                                //                             text: 'กลับสู่หน้าหลัก',
                                //                             onPress: ()=>{
                                //                               return  navigation.navigate("Welcome");
                                //                             }
                                //                         }
                                //                 ]);
                                //                 submit();
                                //                 navigation.navigate("Welcome");
                                //             },
                                //             style: 'cancel',

                                //         },
                                //         {
                                //             text: 'ยกเลิก',
                                //             onPress: () => console.log("Cancel"),
                                //             style: 'cancel',
                                //         },
                                //     ],
                                // )
                                submit();
                                
                            }}
                            
                            buttonStyle={{ padding: 10, width: width / 2.4, marginVertical: 10, borderRadius: 5 }}
                        />
                    </View>
                </View>
            </ScrollView>
            <View style={{ backgroundColor: '#009F83', height: 50, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: '#fff' }}>@10.20.55</Text>
            </View>
        </SafeAreaView>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '#fff',
    },
    scrollView: {
        marginHorizontal: 5,
        marginTop: 25
    },
    textInput: {
        backgroundColor: '#fff',
        borderWidth: 1,
        padding: width / 62.70,
        fontSize: width / 24.813,
        borderRadius: width / 83.3,
        marginTop: 3
    },
    form: {
        padding: width / 24.53,
        marginHorizontal: 10,
    },
    textLabel: {
        fontSize: width / 22.2,
        marginBottom: .5,
        color: '#030000'
    },
    inputItem: {
        padding: 2
    },
    selectionBTN: {
        width: width / 2.1,
        padding: 5,
        marginTop: 5,
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 5
    },
    date: {
        backgroundColor: '#fff',
        borderWidth: 1,
    },
    selectLocation: {
        width: width / 1.77,
        padding: 5,
        marginTop: 5,
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 5
    },
    flatListItem: {
        flexDirection: 'column',
        borderColor: '#3A976B',
        width: width / 1.34,
        borderWidth: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        borderRadius: 7,
        marginHorizontal: 5,
        marginVertical: 5
    }
});


const container = StyleSheet.create({
    container: {
        flexDirection: 'row'
    },
    imgUpload: {
        width: (width / 1.14),
        height: (height / 1.7),
        marginVertical: height / 113
    }
})
