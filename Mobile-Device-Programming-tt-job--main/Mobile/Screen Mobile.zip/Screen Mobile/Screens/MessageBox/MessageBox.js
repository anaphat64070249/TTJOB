import React from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import * as globalFunction from '../../globalFunction';
import axios from "axios";
import { useSelector } from "react-redux";

const mes_demo = [
    {
        message_id: 1000234512,
        message_type: 1,
        message_detail: 1,
        message_sendDay: '2023-10-11',
        com_id: 10000001,
        com_name: "Facebook พระราม2",
        job_id: 10000001,
        dayStart: '2023-10-13',
        timeStart: '13:00',
        timeEnd: '20:20',
    },
    {
        message_id: 1000234512,
        message_type: 1,
        message_detail: 1,
        message_sendDay: '2023-10-11',
        com_id: 10000001,
        com_name: "Facebook พระราม2",
        job_id: 10000001,
        dayStart: '2023-10-13',
        timeStart: '13:00',
        timeEnd: '20:20',
    }
]

export default function MessageBoxScreen({ route, navigation }) {
    const [mes, setMes] = React.useState([]);
    const user = useSelector(res => res.user[0])
    React.useState(() =>{
        axios.get('http://127.0.0.1:5000/message/'+user.emp_id)
        .then((res) =>{
            setMes(res.data);
            console.log(res.data);
            console.log('asssds');
        })
    }, [])

    function render(data) {
        const item = data.item;
        const dayStart = new Date(item.day_start);
        const daySend = new Date(item.message_daySend);
        const mesType = item.message_type == 1 ? 'การสมัครงานของคุณมีการ update' : 'จากผู้จ้าง';
        const mesDetail = item.message_detail == 1 ? 'คุณได้รับการยืนยันจากผู้จ้างงาน' : 'จากผู้จ้าง'
        return (
            <View style={[styles.massageBox]}>
                <Text style={{ fontSize: width / 16, fontWeight: '700' }}>{mesType}</Text>
                <Text style={{ fontSize: width / 21.6, textAlign: 'left' }}>
                    {mesDetail} ที่ {item.companyName}
                    {' '}วันที่{globalFunction.getDay(dayStart.getDay())}
                    {' ' + dayStart.getDate()} {globalFunction.getMonth(dayStart.getMonth())}
                    {' ' + (dayStart.getFullYear() + 543)} {'\n'}เวลา {item.time_start}-{item.time_end}
                    {'\n'}คุรสามารถตรวจสอบได้ที่ "งานของฉัน"
                </Text>
                <Text style={{marginTop: 10, fontSize: width/29, alignSelf: 'flex-end'}}>
                    {daySend.getDate()} {globalFunction.getMonth(daySend.getMonth())}
                    {' ' + (daySend.getFullYear() + 543)}
                </Text>
            </View>

            
        )
    }

    return (
        <View style={[styles.contianer]}>
            <FlatList data={mes} renderItem={render} />
        </View>
    )
}

const styles = StyleSheet.create({
    contianer: {
        flex: 1,
        flexDirection: 'column'
    },
    massageBox: {
        padding: 10,
        borderBottomWidth: 1
    }
})