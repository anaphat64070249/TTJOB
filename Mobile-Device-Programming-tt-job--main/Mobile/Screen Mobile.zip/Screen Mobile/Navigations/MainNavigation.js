import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
// import { createDrawerNavigator } from "@react-navigation/drawer";
import { NavigationContainer } from "@react-navigation/native";
import WelcomeScreen from "../Screens/Authen/WelcomeScreen";
import LoginScreen from "../Screens/Authen/LoginScreen";
import RegisterScreen from "../Screens/Register/RegisterScreen";
import { Dimensions } from 'react-native';
import AppNavigation from "./AppNavigation";
const { width, height } = Dimensions.get('window');

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const Authen = () => {
    return (
        <Stack.Navigator initialRouteName="Welcome"
            screenOptions={{
                headerShown: false, 
                headerStyle: {
                    backgroundColor: '#009F83',
                },
                headerTintColor: '#fff',
                headerTitleStyle:{
                    fontSize: width/19.42,
                },
            }}  
        >
            <Stack.Screen name="Welcome" component={WelcomeScreen} />
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen}
                options={{
                    headerShown: true,
                    title: 'สมัครสมาชิก',
                }}
            />
            <Stack.Screen name="App" component={AppNavigation} />
        </Stack.Navigator>
    )
}

export default function MainNavigation({ route }) {
    return (
        <NavigationContainer >
            <Authen></Authen>
        </NavigationContainer>
    )
}