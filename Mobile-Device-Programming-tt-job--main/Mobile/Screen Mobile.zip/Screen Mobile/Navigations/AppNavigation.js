import React, { useEffect } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import ViewJob from "../Screens/Viewjobs/ViewScreen";
import { StyleSheet } from "react-native";
import { Dimensions } from "react-native";
const { width, height } = Dimensions.get('window');
import ViewJobDetailScreen from "../Screens/Viewjobs/ViewJobDetailScreen";
import { AntDesign } from '@expo/vector-icons';
import { useDispatch, useSelector } from "react-redux";
import * as store from '../store/store'
import Ionicons from '@expo/vector-icons/Ionicons';
import { View, Text, TouchableOpacity } from "react-native";
import MyjobScreen from "../Screens/Viewjobs/MyjobScreen";
// import TabBarButtonCost from "../componeent/Buttons/TabButton";
import TabBarButtonCost from "../componeent/Buttons/TabButtons";
import MessageBoxScreen from "../Screens/MessageBox/MessageBox";
import AccountScreen from "../Screens/Accout/AccountScreen";
import ProfileScreen from "../Screens/Accout/ProfileScreen";
import MyJobHistory from "../Screens/Viewjobs/MyJobHistory";
import { ListJobHisroty } from "../componeent/JobHistory/listJobHistory";
import CustomHeader from "../componeent/Header/Header";
import ReviewScreen from "../Screens/Review/ReviewScreen";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

function StackNavigation({ navigation }) {
    const dispatch = useDispatch();
    function back() {
        dispatch(store.setHeader(true))
    }
    function tabBack() {
        dispatch(store.setTabBar(true));
    }

    console.log(navigation);
    return (
        <Stack.Navigator initialRouteName="ViewJob" screenOptions={{
            headerShown: false,
        }} >
            <Stack.Screen name="ViewJob" component={ViewJob} />
            <Stack.Screen name="ViewDetail"
                options={{
                    headerShown: true,
                    header: (({ navigation }) => {
                        return (
                            <CustomHeader
                                arrow={true}
                                title={"รายละเอียดงาน"}
                                navigation={navigation}
                                go={'ViewJob'}
                                back={back} tabBack={tabBack}
                            />
                        )
                    })
                }}
                component={ViewJobDetailScreen}
            />
        </Stack.Navigator>
    )
}

function ViewMyJob({ navigation }) {

    const dispatch = useDispatch();
    function back() {
        dispatch(store.setHeader(true))
    }
    function tabBack() {
        dispatch(store.setTabBar(true));
    }
    return (
        <Stack.Navigator initialRouteName="ViewMyjob">
            <Stack.Screen name="ViewMyJob" component={MyjobScreen}
                options={{
                    // title: 'งานของฉัน',
                    // headerStyle: [styles.header, ],
                    // headerTintColor: '#fff',
                    // headerTitleStyle: {
                    //     fontSize: width / 14.2
                    // }

                    header: (({ navigation }) => {
                        return (
                            <CustomHeader
                                title={"งานของฉัน"}
                                navigation={navigation}
                                go={''}
                            />
                        )
                    })
                }} >
            </Stack.Screen>
            <Stack.Screen name="Review" component={ReviewScreen}
                options={{
                    title: 'ประเมินผู้จ้าง',
                    headerStyle: {
                        backgroundColor: '#009F83'
                    },
                    headerTitleStyle: {
                        color: '#fff'
                    },
                    headerTintColor: "#fff"
                }}
            />
        </Stack.Navigator>
    )
}

function TabNavigation({ route, navigation }) {
    const tab = useSelector(state => state.tabBarShow);
    console.log("on Tab:", tab);
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                headerShown: false,
                tabBarStyle: [styles.tabContianer,],
                tabBarLabelStyle: {
                    color: '#fff',
                    fontSize: width / 23.5,
                    padding: 5,
                }
            })} initialRouteName="FindJob">
            <Tab.Screen name="FindJob" component={StackNavigation}
                options={{
                    headerShown: false,
                    tabBarStyle: [styles.tabContianer, tab ? {} : { display: 'none' }],
                    tabBarButton: () => {
                        return (
                            <TabBarButtonCost name={'human'}
                                title={'ประกาศงาน'}
                                header={true}
                                tabBar={true}
                                navigate={'FindJob'}
                                navigation={navigation}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="Myjob" component={ViewMyJob}
                options={{
                    headerShown: false,
                    tabBarButton: () => {
                        return (
                            <TabBarButtonCost name={'clipboard-text-multiple-outline'}
                                title={"งานของฉัน"}
                                header={false}
                                tabBar={true}
                                navigate={'Myjob'}
                                navigation={navigation}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="MassageBox" component={MessageBoxScreen}
                options={{
                    headerShown: true,
                    headerTintColor: '#fff',
                    headerTitleStyle: {
                        fontSize: width / 14.2
                    },
                    headerStyle: [styles.header],
                    tabBarStyle: [styles.tabContianer, tab ? {} : { display: 'none' }],
                    tabBarButton: () => {
                        return (
                            <TabBarButtonCost name={'email'}
                                title={'ข้อความ'}
                                header={false}
                                tabBar={true}
                                navigate={'MassageBox'}
                                navigation={navigation}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="Account" component={AccountScreen}
                options={{
                    headerShown: true,
                    headerTintColor: '#fff',
                    headerTitleStyle: {
                        fontSize: width / 14.2
                    },
                    headerStyle: [styles.header],
                    tabBarStyle: [styles.tabContianer, tab ? {} : { display: 'none' }],
                    tabBarButton: () => {
                        return (
                            <TabBarButtonCost
                                name={'account'}
                                title={'บัญชีของฉัน'}
                                header={false}
                                tabBar={true}
                                navigate={'Account'}
                                navigation={navigation}
                            />
                        )
                    }
                }}
            />
        </Tab.Navigator>
    )
}

function JobStack({ navigation, route }) {
    const dispatch = useDispatch();

    function back() {
        dispatch(store.setHeader(true))
    }
    function headerNotshow(){
        dispatch(store.setHeader(false));
    }
    function tabBack() {
        dispatch(store.setTabBar(true));
    }

    return (
        <Stack.Navigator>
            <Stack.Screen name="MyJobHistory" component={MyJobHistory}
                options={{
                    headerShown: false
                }}
            />
            <Stack.Screen name="MyJobList" component={ListJobHisroty}
                options={({ route }) => ({
                    header: (({ navigation, route }) => {
                        return (
                            <CustomHeader
                                arrow={true}
                                drawerbar={false}
                                title={route.params.title}
                                navigation={navigation}
                                go={'MyJobHistory'}
                                back={back} tabBack={tabBack}
                            />
                        )
                    })
                })}
                
            />
        </Stack.Navigator>
    )
}

function DrawerNavigation({ navigation, route }) {
    const dispatch = useDispatch();

    // useEffect(() => {
    //     try {
    //         console.log("route", navigation);
    //         if(navigation.name === "MyJobList"){
    //             console.log("set false");
    //             dispatch(store.setHeader(false))
    //         }else{
    //             dispatch(store.setHeader(true))
    //         }
    //     } catch (e) {
    //         dispatch(store.setHeader(true))
    //     }
    // });

    const tab = useSelector(state => state.headerShow);
    console.log("State header", tab);


    return (
        <Drawer.Navigator screenOptions={{
            headerStyle: styles.header,
            headerTintColor: '#fff',
            headerShown: tab,
        }}>
            <Drawer.Screen name="TabNavigation" component={TabNavigation}
                options={({ route }) => ({
                    title: 'หน้าประกาศงาน',
                })}
            />
            <Drawer.Screen name="Profile" component={ProfileScreen}
                options={{
                    title: 'ข้อมูลส่วนตัว'
                }}
            />
            <Drawer.Screen name="History" component={JobStack}
                options={{
                    title: 'ประวัติการทำงาน'
                }}
            />
        </Drawer.Navigator>
    )
}

// function Drawer

export default function AppNavigation() {
    return (
        <DrawerNavigation></DrawerNavigation>
    )
}

const styles = StyleSheet.create({
    tabContianer: {
        padding: 5,
        backgroundColor: '#03BA99',
        height: height / 8
    },
    header: {
        backgroundColor: '#009F83',
    }
})