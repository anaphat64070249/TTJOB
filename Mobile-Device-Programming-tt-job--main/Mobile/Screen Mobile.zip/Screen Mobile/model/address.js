import amper from '../datas/amper.json';
import provinces from '../datas/provinces.json';
import tumbon from '../datas/tumbon.json'

export function GetProvice(){
    const res = provinces.RECORDS;
    return res;
}


export function GetAmper(province_id){
    const amp = [];
    amper.RECORDS.forEach(item => {
        if (item.province_id == province_id){
            amp.push(item);
        }
    });
    return amp
}


export function GetTumbon(amphure_id){
    const tbn = [];
    tumbon.RECORDS.forEach(item =>{
        if (item.amphure_id == amphure_id){
            tbn.push(item)
        }
    });
    return tbn;
}